<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="overflow-x-hidden">
    <?php
        include 'navbar.php';
    ?>
    <nav class="ml-53 min-h-screen flex-1 ">
        <div class="w-full bg-gray-300 h-fit p-4">
            <p class="font-bold ">SALES</p>
        </div>
    </nav>
</body>
</html>