<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include "db.php";

date_default_timezone_set('Asia/Manila');
$currentDateTime = date('n/j/Y - g:iA');

$currentUser = $_SESSION['username'] ?? $_SESSION['full_name'] ?? $_SESSION['name'] ?? 'Guest';
$currentPage = basename($_SERVER['PHP_SELF']);

if (isset($_SESSION['user_id'])) {
    $userId = (int) $_SESSION['user_id'];

    $stmt = $conn->prepare("
        UPDATE users
        SET status = 'online', last_activity = NOW()
        WHERE id = ?
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
}

function navClass(array $pages, string $currentPage): string
{
    $isActive = in_array($currentPage, $pages, true);

    if ($isActive) {
        return "bg-white text-orange-500 border-white shadow-md";
    }

    return "border-orange-400 text-white hover:border-orange-800 hover:bg-orange-800";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Navbar</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Iosevka+Charon:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500;1,700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style type="text/tailwindcss">
        @reference "tailwindcss";
        @theme{
            --font-roboto: "ROBOTO", "sans-serif";
        }

        body{
            @apply font-roboto;
        }

        h1{
            @apply font-bold text-[1.3rem];
        }

        h2{
            @apply font-bold text-[1rem];
        }

        * {
            caret-color: transparent;
        }

        input[type="text"],
        input[type="search"],
        input[type="password"],
        input[type="email"],
        input[type="number"],
        textarea,
        [contenteditable="true"] {
            caret-color: auto;
        }
    </style>
</head>
<body class="overflow-x-hidden bg-orange-50">
    <!-- top navbar -->
    <nav class="fixed top-0 left-0 w-full z-50">
        <div class="w-screen bg-orange-50 p-4 shadow-sm flex items-center justify-evenly gap-4 border-b border-orange-100">
            <div class="flex items-center gap-4 max-sm:flex-col">
                <h1 class="text-orange-500">Anna MART</h1>
            </div>
            <h2 class="text-gray-700"><?= htmlspecialchars($currentDateTime) ?></h2>
            <div class="flex items-center gap-3 flex-wrap justify-end">
                <div class="bg-white border border-orange-200 px-4 py-2 rounded-2xl flex items-center gap-2 shadow-sm">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5 text-orange-500">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.964 0a9 9 0 1 0-11.964 0m11.964 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>
                    <div class="leading-tight">
                        <p class="text-xs text-gray-500 font-medium">Current User</p>
                        <p class="text-sm font-bold text-gray-800"><?= htmlspecialchars($currentUser) ?></p>
                    </div>
                </div>

                <a href="products.php" class="bg-orange-400 border-orange-400 text-white border-2 px-4 py-2 rounded-2xl flex items-center gap-2 hover:bg-white hover:text-orange-400 cursor-pointer transition">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4">
                        <path fill-rule="evenodd" d="M15 3.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0V5.56l-3.97 3.97a.75.75 0 1 1-1.06-1.06l3.97-3.97h-2.69a.75.75 0 0 1-.75-.75Zm-12 0A.75.75 0 0 1 3.75 3h4.5a.75.75 0 0 1 0 1.5H5.56l3.97 3.97a.75.75 0 0 1-1.06 1.06L4.5 5.56v2.69a.75.75 0 0 1-1.5 0v-4.5Zm11.47 11.78a.75.75 0 1 1 1.06-1.06l3.97 3.97v-2.69a.75.75 0 0 1 1.5 0v4.5a.75.75 0 0 1-.75.75h-4.5a.75.75 0 0 1 0-1.5h2.69l-3.97-3.97Zm-4.94-1.06a.75.75 0 0 1 0 1.06L5.56 19.5h2.69a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 1 1.5 0v2.69l3.97-3.97a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />
                    </svg>
                    <span class="font-medium">PRODUCTS</span>
                </a>
            </div>
        </div>
    </nav>

    <!-- side -->
    <nav class="fixed top-20 left-0 m-3 z-40">
        <div class="bg-orange-400 shadow-sm h-[calc(100vh-6.5rem)] py-2 w-auto rounded-2xl flex flex-col justify-between">
            <div class="flex flex-col items-stretch m-2 gap-2">
                <a href="home.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['home.php', 'index.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['home.php', 'index.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                    </svg>
                    <span class="font-bold">HOME</span>
                </a>

                <a href="inventory.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['inventory.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['inventory.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m20.25 7.5-.625 10.632a2.25 2.25 0 0 1-2.247 2.118H6.622a2.25 2.25 0 0 1-2.247-2.118L3.75 7.5m8.25 3v6.75m0 0-3-3m3 3 3-3M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125Z" />
                    </svg>
                    <span class="font-bold">INVENTORY</span>
                </a>

                <a href="products.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['products.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['products.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
                    </svg>
                    <span class="font-bold">PRODUCTS</span>
                </a>

                <a href="transactions.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['transactions.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['transactions.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.057 1.123-.08M15.75 18H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08M15.75 18.75v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5A3.375 3.375 0 0 0 6.375 7.5H5.25m11.9-3.664A2.251 2.251 0 0 0 15 2.25h-1.5a2.251 2.251 0 0 0-2.15 1.586m5.8 0c.065.21.1.433.1.664v.75h-6V4.5c0-.231.035-.454.1-.664M6.75 7.5H4.875c-.621 0-1.125.504-1.125 1.125v12c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V16.5a9 9 0 0 0-9-9Z" />
                    </svg>
                    <span class="font-bold">TRANSACTIONS</span>
                </a>

                <a href="transactions_items.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['transactions_items.php', 'transaction_items.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['transactions_items.php', 'transaction_items.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.057 1.123-.08M15.75 18H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08M15.75 18.75v-1.875a3.375 3.375 0 0 0-3.375-3.375h-1.5a1.125 1.125 0 0 1-1.125-1.125v-1.5A3.375 3.375 0 0 0 6.375 7.5H5.25m11.9-3.664A2.251 2.251 0 0 0 15 2.25h-1.5a2.251 2.251 0 0 0-2.15 1.586m5.8 0c.065.21.1.433.1.664v.75h-6V4.5c0-.231.035-.454.1-.664M6.75 7.5H4.875c-.621 0-1.125.504-1.125 1.125v12c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V16.5a9 9 0 0 0-9-9Z" />
                    </svg>
                    <span class="font-bold">TRANSACTION ITEMS</span>
                </a>

                <a href="reports.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['reports.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['users.php'], true) ? 'text-white' : 'text-orange' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 3v1.5M3 21v-6m0 0 2.77-.693a9 9 0 0 1 6.208.682l.108.054a9 9 0 0 0 6.086.71l3.114-.732a48.524 48.524 0 0 1-.005-10.499l-3.11.732a9 9 0 0 1-6.085-.711l-.108-.054a9 9 0 0 0-6.208-.682L3 4.5M3 15V4.5" />
                    </svg>
                    <span class="font-bold">REPORTS</span>
                </a>
                <a href="users.php" class="border-2 w-full p-3 rounded-[12px] px-4 flex items-center transition <?= navClass(['users.php'], $currentPage) ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-4 <?= in_array($currentPage, ['users.php'], true) ? 'text-orange-500' : 'text-white' ?>">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                    </svg>
                    <span class="font-bold">USERS</span>
                </a>
            </div>

            <div class="m-2 mt-4 border-t border-orange-300 pt-3">
                <div class="bg-orange-300/30 rounded-xl px-3 py-3 mb-3 flex flex-row items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-10 text-white">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.964 0a9 9 0 1 0-11.964 0m11.964 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                    </svg>
                    <div class="ml-11 text-center">
                        <p class="text-[11px] text-orange-50/80">Logged in as</p>
                        <p class="text-sm font-bold text-white truncate"><?= htmlspecialchars($currentUser) ?></p>
                    </div>
                </div>

                <button id="openLogoutWindow" type="button" class="w-full bg-red-500 border-red-500 text-white border-2 px-4 py-3 rounded-[12px] flex items-center justify-center hover:bg-white hover:text-orange-400 cursor-pointer transition">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6 mr-1 mb-1">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6A2.25 2.25 0 0 0 5.25 5.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
                    </svg>
                    <span class="font-bold">LOGOUT</span>
                </button>
            </div>
        </div>
    </nav>

    <div id="logoutWindowWrapper" class="hidden fixed inset-0 z-[999]">
        <div id="logoutWindowOverlay" class="absolute inset-0 bg-black/20 backdrop-blur-[1px]"></div>

        <div id="logoutFloatingWindow" class="absolute top-24 left-28 w-[360px] bg-white rounded-2xl shadow-2xl border border-red-100 overflow-hidden">
            <div class="bg-red-500 px-4 py-3 flex items-center justify-between">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.8" stroke="currentColor" class="size-4 text-white">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6A2.25 2.25 0 0 0 5.25 5.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15m3 0 3-3m0 0-3-3m3 3H9" />
                        </svg>
                    </div>
                    <p class="text-white font-bold">Logout Window</p>
                </div>

                <button id="closeLogoutWindow" type="button" class="text-white hover:bg-white/20 w-8 h-8 rounded-full cursor-pointer">
                    ✕
                </button>
            </div>

            <div class="p-5">
                <p class="text-gray-800 font-semibold mb-1">Sign out of the system?</p>
                <p class="text-sm text-gray-500 mb-4">
                    Current user:
                    <span class="font-bold text-orange-500"><?= htmlspecialchars($currentUser) ?></span>
                </p>

                <div class="bg-orange-50 border border-orange-100 rounded-xl p-3 mb-4">
                    <p class="text-sm text-gray-600">
                        You are about to logout from your current POS session.
                    </p>
                </div>

                <div class="flex justify-end gap-2">
                    <button id="cancelLogoutWindow" type="button" class="px-4 py-2 rounded-xl bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold cursor-pointer">
                        Cancel
                    </button>
                    <a href="login.php?logout=1" class="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-600 text-white font-semibold">
                        Logout
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        const openLogoutWindow = document.getElementById('openLogoutWindow');
        const logoutWindowWrapper = document.getElementById('logoutWindowWrapper');
        const closeLogoutWindow = document.getElementById('closeLogoutWindow');
        const cancelLogoutWindow = document.getElementById('cancelLogoutWindow');
        const logoutWindowOverlay = document.getElementById('logoutWindowOverlay');

        function showLogoutWindow() {
            logoutWindowWrapper.classList.remove('hidden');
        }

        function hideLogoutWindow() {
            logoutWindowWrapper.classList.add('hidden');
        }

        if (openLogoutWindow) {
            openLogoutWindow.addEventListener('click', showLogoutWindow);
        }

        if (closeLogoutWindow) {
            closeLogoutWindow.addEventListener('click', hideLogoutWindow);
        }

        if (cancelLogoutWindow) {
            cancelLogoutWindow.addEventListener('click', hideLogoutWindow);
        }

        if (logoutWindowOverlay) {
            logoutWindowOverlay.addEventListener('click', hideLogoutWindow);
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                hideLogoutWindow();
            }
        });
    </script>
</body>
</html>