<?php
include "db.php";

/* DASHBOARD COUNTS */

// Total Sales
$totalSales = 0;
$salesQuery = $conn->query("SELECT IFNULL(SUM(total_amount), 0) AS total_sales FROM transactions");
if ($salesQuery && $salesRow = $salesQuery->fetch_assoc()) {
    $totalSales = (float)$salesRow['total_sales'];
}

// Total Transactions
$totalTransactions = 0;
$transactionsQuery = $conn->query("SELECT COUNT(*) AS total_transactions FROM transactions");
if ($transactionsQuery && $transactionsRow = $transactionsQuery->fetch_assoc()) {
    $totalTransactions = (int)$transactionsRow['total_transactions'];
}

// Total Products
$totalProducts = 0;
$productsQuery = $conn->query("SELECT COUNT(*) AS total_products FROM products");
if ($productsQuery && $productsRow = $productsQuery->fetch_assoc()) {
    $totalProducts = (int)$productsRow['total_products'];
}

// Low Stock Items
$lowStockCount = 0;
$lowStockQuery = $conn->query("SELECT COUNT(*) AS low_stock_count FROM products WHERE stock_qty <= 5");
if ($lowStockQuery && $lowStockRow = $lowStockQuery->fetch_assoc()) {
    $lowStockCount = (int)$lowStockRow['low_stock_count'];
}

// Recent Transactions
$recentTransactions = $conn->query("
    SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
    FROM transactions
    ORDER BY id DESC
    LIMIT 5
");

// Top Selling Products
$topSellingProducts = $conn->query("
    SELECT 
        product_name,
        SUM(qty) AS total_qty,
        SUM(subtotal) AS total_sales
    FROM transaction_items
    GROUP BY product_name
    ORDER BY total_qty DESC, total_sales DESC
    LIMIT 5
");

// Low Stock Product List
$lowStockProducts = $conn->query("
    SELECT product_name, stock_qty, price
    FROM products
    WHERE stock_qty <= 5
    ORDER BY stock_qty ASC, product_name ASC
    LIMIT 10
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="overflow-x-hidden bg-orange-50">
    <?php include 'navbar.php'; ?>

    <!-- main body content -->
    <main class="ml-69 mt-24 min-h-screen p-4">
        <!-- Header -->
        <div class="w-full bg-white shadow-sm p-5 rounded-2xl mb-4 border border-orange-100">
            <p class="font-bold text-2xl text-orange-500">HOME</p>
            <p class="text-gray-500 text-sm mt-1">Sales and Inventory Dashboard</p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
            <!-- total sales -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5 flex flex-row-reverse justify-between">
                <div>
                    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" class="size-14">
                        <rect x="8" y="16" width="48" height="32" rx="8" fill="#F97316"/>
                        <rect x="8" y="22" width="48" height="8" fill="#EA580C"/>
                        <circle cx="46" cy="36" r="4" fill="white"/>
                        <path d="M20 42L28 34L34 40L44 28" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M40 28H44V32" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500 font-medium">Total Sales</p>
                    <h2 class="text-3xl font-bold text-orange-500 mt-2">₱<?= number_format($totalSales, 2) ?></h2>
                </div>
            </div>
            <!-- total transactions -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5 flex flex-row-reverse justify-between">
                <div>
                    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" class="size-12">
                        <rect x="12" y="10" width="40" height="44" rx="8" fill="#F97316"/>
                        <rect x="18" y="18" width="28" height="4" rx="2" fill="white"/>
                        <rect x="18" y="28" width="20" height="4" rx="2" fill="white"/>
                        <rect x="18" y="38" width="16" height="4" rx="2" fill="white"/>
                        <circle cx="46" cy="44" r="10" fill="#EA580C"/>
                        <path d="M46 39V44L49 47" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500 font-medium">Total Transactions</p>
                    <h2 class="text-3xl font-bold text-orange-500 mt-2"><?= $totalTransactions ?></h2>
                </div>
            </div>
            <!-- total productions -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5 flex flex-row-reverse justify-between">
                <div>
                    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" class="size-14">
                        <rect x="10" y="18" width="44" height="30" rx="8" fill="#F97316"/>
                        <rect x="16" y="24" width="10" height="18" rx="2" fill="white"/>
                        <rect x="30" y="20" width="10" height="22" rx="2" fill="white"/>
                        <rect x="44" y="28" width="4" height="4" rx="1" fill="white"/>
                        <path d="M20 14V8" stroke="#EA580C" stroke-width="3" stroke-linecap="round"/>
                        <path d="M32 14V8" stroke="#EA580C" stroke-width="3" stroke-linecap="round"/>
                        <path d="M44 14V8" stroke="#EA580C" stroke-width="3" stroke-linecap="round"/>
                        <path d="M8 48H56" stroke="#C2410C" stroke-width="3" stroke-linecap="round"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500 font-medium">Total Products</p>
                    <h2 class="text-3xl font-bold text-orange-500 mt-2"><?= $totalProducts ?></h2>
                </div>
            </div>
            <!-- low stock items -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5 flex flex-row-reverse justify-between">
                <div>
                    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" class="size-14">
                        <rect x="10" y="16" width="44" height="32" rx="8" fill="#EF4444"/>
                        <rect x="16" y="24" width="20" height="6" rx="3" fill="white"/>
                        <rect x="16" y="34" width="12" height="6" rx="3" fill="white"/>
                        <circle cx="46" cy="40" r="10" fill="#DC2626"/>
                        <path d="M46 35V41" stroke="white" stroke-width="3" stroke-linecap="round"/>
                        <circle cx="46" cy="45" r="1.8" fill="white"/>
                    </svg>
                </div>
                <div>
                    <p class="text-sm text-gray-500 font-medium">Low Stock Items</p>
                    <h2 class="text-3xl font-bold text-red-500 mt-2"><?= $lowStockCount ?></h2>
                </div>
            </div>
        </div>

        <!-- Middle Grid -->
        <div class="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
            <!-- Recent Transactions -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-bold text-orange-500">Recent Transactions</h2>
                    <a href="transactions.php" class="text-sm text-orange-500 font-semibold hover:underline">View All</a>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-orange-100 text-left">
                                <th class="p-3">Receipt</th>
                                <th class="p-3">Total</th>
                                <th class="p-3">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recentTransactions && $recentTransactions->num_rows > 0): ?>
                                <?php while ($row = $recentTransactions->fetch_assoc()): ?>
                                    <tr class="border-b hover:bg-orange-50">
                                        <td class="p-3 font-medium"><?= htmlspecialchars($row['receipt_no']) ?></td>
                                        <td class="p-3">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                        <td class="p-3">
                                            <?= !empty($row['created_at']) ? date("M d, Y h:i A", strtotime($row['created_at'])) : 'N/A' ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="p-4 text-center text-gray-500">No transactions yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Top Selling Products -->
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-bold text-orange-500">Top Selling Products</h2>
                    <a href="transactions_items.php" class="text-sm text-orange-500 font-semibold hover:underline">View Items</a>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-orange-100 text-left">
                                <th class="p-3">Product</th>
                                <th class="p-3">Qty Sold</th>
                                <th class="p-3">Sales</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($topSellingProducts && $topSellingProducts->num_rows > 0): ?>
                                <?php while ($row = $topSellingProducts->fetch_assoc()): ?>
                                    <tr class="border-b hover:bg-orange-50">
                                        <td class="p-3 font-medium"><?= htmlspecialchars($row['product_name']) ?></td>
                                        <td class="p-3"><?= (int)$row['total_qty'] ?></td>
                                        <td class="p-3">₱<?= number_format((float)$row['total_sales'], 2) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="p-4 text-center text-gray-500">No sales data yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Low Stock Inventory -->
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-orange-500">Low Stock Inventory</h2>
                <a href="inventory.php" class="text-sm text-orange-500 font-semibold hover:underline">View Inventory</a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-orange-100 text-left">
                            <th class="p-3">Product Name</th>
                            <th class="p-3">Stock</th>
                            <th class="p-3">Price</th>
                            <th class="p-3">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($lowStockProducts && $lowStockProducts->num_rows > 0): ?>
                            <?php while ($row = $lowStockProducts->fetch_assoc()): ?>
                                <tr class="border-b hover:bg-orange-50">
                                    <td class="p-3 font-medium"><?= htmlspecialchars($row['product_name']) ?></td>
                                    <td class="p-3"><?= (int)$row['stock_qty'] ?></td>
                                    <td class="p-3">₱<?= number_format((float)$row['price'], 2) ?></td>
                                    <td class="p-3">
                                        <?php if ((int)$row['stock_qty'] <= 0): ?>
                                            <span class="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm font-semibold">Out of Stock</span>
                                        <?php else: ?>
                                            <span class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full text-sm font-semibold">Low Stock</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="p-4 text-center text-gray-500">No low stock items.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>