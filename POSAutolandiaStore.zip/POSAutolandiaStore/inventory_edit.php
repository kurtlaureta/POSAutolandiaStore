<?php
include "db.php";

$message = "";
$success = false;

$product_id = (int)($_GET["product_id"] ?? $_POST["product_id"] ?? 0);

$stmt = $conn->prepare("
    SELECT p.*, c.category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["save_product"])) {
    $product_name = trim($_POST["product_name"] ?? "");
    $price = (float)($_POST["price"] ?? 0);
    $barcode = trim($_POST["barcode"] ?? "");

    if ($product_name === "" || $price <= 0) {
        $message = "Please fill in the required fields.";
    } else {
        $conn->begin_transaction();

        try {
            $updateProduct = $conn->prepare("
                UPDATE products
                SET product_name = ?, price = ?
                WHERE id = ?
            ");
            $updateProduct->bind_param("sdi", $product_name, $price, $product_id);
            $updateProduct->execute();

            if ($barcode !== "") {
                $checkExisting = $conn->prepare("
                    SELECT id FROM product_barcodes
                    WHERE product_id = ? AND barcode = ?
                    LIMIT 1
                ");
                $checkExisting->bind_param("is", $product_id, $barcode);
                $checkExisting->execute();
                $exists = $checkExisting->get_result()->fetch_assoc();

                if (!$exists) {
                    $insertBarcode = $conn->prepare("
                        INSERT INTO product_barcodes (product_id, barcode, is_sold)
                        VALUES (?, ?, 0)
                    ");
                    $insertBarcode->bind_param("is", $product_id, $barcode);
                    $insertBarcode->execute();

                    $updateStock = $conn->prepare("
                        UPDATE products
                        SET stock_qty = stock_qty + 1
                        WHERE id = ?
                    ");
                    $updateStock->bind_param("i", $product_id);
                    $updateStock->execute();
                }
            }

            $conn->commit();
            $message = "Product updated successfully.";
            $success = true;
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Update failed: " . $e->getMessage();
        }
    }

    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold text-orange-500">Edit Product</h1>
            <a href="inventory.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                Back
            </a>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-4">
            <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">

            <div>
                <label class="block font-medium mb-1">Product Name</label>
                <input type="text" name="product_name" value="<?= htmlspecialchars($product['product_name']) ?>" class="w-full border rounded-xl px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">Price</label>
                <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($product['price']) ?>" class="w-full border rounded-xl px-4 py-2" required>
            </div>

            <div>
                <label class="block font-medium mb-1">Add Barcode (Optional)</label>
                <input type="text" name="barcode" class="w-full border rounded-xl px-4 py-2" placeholder="Scan or type barcode to add one stock">
                <p class="text-sm text-gray-500 mt-1">
                    If you add a new barcode here, stock increases by 1 automatically.
                </p>
            </div>

            <button type="submit" name="save_product" class="bg-orange-400 hover:bg-orange-500 text-white px-6 py-2 rounded-xl font-semibold">
                Save Changes
            </button>
        </form>
    </div>
</body>
</html>