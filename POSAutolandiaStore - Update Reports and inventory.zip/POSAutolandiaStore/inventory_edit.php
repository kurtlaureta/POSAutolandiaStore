<?php
include "db.php";

$message = "";
$success = false;

$product_id = (int)($_GET["product_id"] ?? $_POST["product_id"] ?? 0);

$stmt = $conn->prepare("
    SELECT p.*, c.category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.id = ?
    LIMIT 1
");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["save_product"])) {
    $product_name = trim($_POST["product_name"] ?? "");
    $price = (float)($_POST["price"] ?? 0);
    $barcode = trim($_POST["barcode"] ?? "");

    if ($product_name === "" || $price <= 0) {
        $message = "Please fill in the required fields.";
    } else {
        $conn->begin_transaction();

        try {
            $updateProduct = $conn->prepare("
                UPDATE products
                SET product_name = ?, price = ?
                WHERE id = ?
            ");
            $updateProduct->bind_param("sdi", $product_name, $price, $product_id);
            $updateProduct->execute();

            if ($barcode !== "") {
                // Check if barcode already exists anywhere in the system
                $checkBarcode = $conn->prepare("
                    SELECT id, product_id
                    FROM product_barcodes
                    WHERE barcode = ?
                    LIMIT 1
                ");
                $checkBarcode->bind_param("s", $barcode);
                $checkBarcode->execute();
                $barcodeResult = $checkBarcode->get_result();
                $existingBarcode = $barcodeResult->fetch_assoc();

                if ($existingBarcode) {
                    $existingProductId = (int)$existingBarcode["product_id"];

                    if ($existingProductId === $product_id) {
                        // Barcode already belongs to this same product
                        $message = "Barcode already exists for this product. No duplicate barcode row was added and stock was not changed.";
                        $success = true;
                    } else {
                        // Barcode belongs to another product
                        throw new Exception("This barcode already belongs to another product.");
                    }
                } else {
                    // Insert only if truly new
                    $insertBarcode = $conn->prepare("
                        INSERT INTO product_barcodes (product_id, barcode, is_sold)
                        VALUES (?, ?, 0)
                    ");
                    $insertBarcode->bind_param("is", $product_id, $barcode);
                    $insertBarcode->execute();

                    $updateStock = $conn->prepare("
                        UPDATE products
                        SET stock_qty = stock_qty + 1
                        WHERE id = ?
                    ");
                    $updateStock->bind_param("i", $product_id);
                    $updateStock->execute();

                    $message = "Product updated successfully. New barcode added and stock increased by 1.";
                    $success = true;
                }
            } else {
                $message = "Product updated successfully.";
                $success = true;
            }

            $conn->commit();
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Update failed: " . $e->getMessage();
        }
    }

    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
}

// Load barcodes for display
$barcodeStmt = $conn->prepare("
    SELECT id, barcode, is_sold
    FROM product_barcodes
    WHERE product_id = ?
    ORDER BY id ASC
");
$barcodeStmt->bind_param("i", $product_id);
$barcodeStmt->execute();
$barcodeResult = $barcodeStmt->get_result();

$barcodeList = [];
while ($row = $barcodeResult->fetch_assoc()) {
    $barcodeList[] = $row;
}
$barcodeCount = count($barcodeList);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h1 class="text-2xl font-bold text-orange-500">Edit Product</h1>
                <p class="text-sm text-gray-500">Update product details and safely manage barcode without duplicates.</p>
            </div>
            <a href="inventory.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                Back
            </a>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="mb-4 grid grid-cols-1 md:grid-cols-3 gap-3">
            <div class="bg-orange-50 border border-orange-100 rounded-xl p-4">
                <p class="text-xs uppercase tracking-wide text-gray-500">Current Stock</p>
                <p class="text-2xl font-bold text-orange-600 mt-1"><?= (int)$product['stock_qty'] ?></p>
            </div>
            <div class="bg-orange-50 border border-orange-100 rounded-xl p-4">
                <p class="text-xs uppercase tracking-wide text-gray-500">Barcode Rows</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?= $barcodeCount ?></p>
            </div>
            <div class="bg-orange-50 border border-orange-100 rounded-xl p-4">
                <p class="text-xs uppercase tracking-wide text-gray-500">Category</p>
                <p class="text-lg font-semibold text-gray-800 mt-1"><?= htmlspecialchars($product['category_name'] ?? 'N/A') ?></p>
            </div>
        </div>

        <form method="POST" class="space-y-4">
            <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">

            <div>
                <label class="block font-medium mb-1">Product Name</label>
                <input
                    type="text"
                    name="product_name"
                    value="<?= htmlspecialchars($product['product_name']) ?>"
                    class="w-full border rounded-xl px-4 py-2"
                    required
                >
            </div>

            <div>
                <label class="block font-medium mb-1">Price</label>
                <input
                    type="number"
                    step="0.01"
                    name="price"
                    value="<?= htmlspecialchars($product['price']) ?>"
                    class="w-full border rounded-xl px-4 py-2"
                    required
                >
            </div>

            <div>
                <label class="block font-medium mb-1">Add Barcode (Optional)</label>
                <input
                    type="text"
                    name="barcode"
                    class="w-full border rounded-xl px-4 py-2"
                    placeholder="Scan or type a NEW barcode"
                >
                <p class="text-sm text-gray-500 mt-1">
                    Only brand new barcode values will be inserted. Existing barcode values will not be duplicated.
                </p>
            </div>

            <button
                type="submit"
                name="save_product"
                class="bg-orange-400 hover:bg-orange-500 text-white px-6 py-2 rounded-xl font-semibold"
            >
                Save Changes
            </button>
        </form>

        <div class="mt-8">
            <h2 class="text-lg font-bold text-orange-500 mb-3">Existing Barcodes</h2>

            <div class="bg-orange-50 border border-orange-100 rounded-2xl p-4 max-h-72 overflow-y-auto">
                <?php if (!empty($barcodeList)): ?>
                    <div class="space-y-2">
                        <?php foreach ($barcodeList as $code): ?>
                            <div class="flex items-center justify-between bg-white border border-orange-100 rounded-xl px-4 py-3">
                                <div>
                                    <p class="font-medium text-gray-800"><?= htmlspecialchars($code['barcode']) ?></p>
                                    <p class="text-xs text-gray-500">
                                        Status: <?= (int)$code['is_sold'] === 1 ? 'Sold' : 'Available' ?>
                                    </p>
                                </div>
                                <span class="px-3 py-1 rounded-full text-xs font-semibold <?= (int)$code['is_sold'] === 1 ? 'bg-gray-200 text-gray-700' : 'bg-green-100 text-green-700' ?>">
                                    <?= (int)$code['is_sold'] === 1 ? 'Used' : 'Active' ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-sm text-gray-500">No barcode records found for this product.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>