<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Document</title>
</head>
<body>
    <section class="bg-gray-800 p-2 fixed">
        <div class="flex flex-col justify-between w-fit h-screen">
            <div class="m-2">
                <div class="border-b border-gray-700 flex flex-col">
                    <div class="text-white flex justify-start">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 mr-1 text-orange-500">
                            <path fill-rule="evenodd" d="M7.5 6v.75H5.513c-.96 0-1.764.724-1.865 1.679l-1.263 12A1.875 1.875 0 0 0 4.25 22.5h15.5a1.875 1.875 0 0 0 1.865-2.071l-1.263-12a1.875 1.875 0 0 0-1.865-1.679H16.5V6a4.5 4.5 0 1 0-9 0ZM12 3a3 3 0 0 0-3 3v.75h6V6a3 3 0 0 0-3-3Zm-3 8.25a3 3 0 1 0 6 0v-.75a.75.75 0 0 1 1.5 0v.75a4.5 4.5 0 1 1-9 0v-.75a.75.75 0 0 1 1.5 0v.75Z" clip-rule="evenodd" />
                        </svg>
                        <p class="font-bold">AUTOLANDIA STORE</p>
                    </div>
                    <p class="text-[12px] font-light text-gray-400 text-center mb-4 mt-1">Autolandia point of sale system</p>
                </div>
                <div class="py-2">
                    <ul class="flex flex-col gap-2 justify-center mt-2">
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">HOME</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">SALES</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">ITEMS</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">INVENTORY</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">CUSTOMERS</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">EMPLOYEES</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">REPORTS</li>
                        <li class="cursor-pointer border w-full p-2 text-white font-medium rounded-3xl text-center hover:bg-orange-500 hover:border-orange-500 bg-gray-700 border-gray-700">SETTINGS</li>
                    </ul>
                </div>
            </div>
            <div class="px-2 border-t border-gray-700">
                <div class="flex w-full bg-gray-800 p-3 rounded-2xl mt-4 border-gray-700 border">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-12 text-orange-300">
                        <path fill-rule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438ZM15.75 9a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" clip-rule="evenodd" />
                    </svg>
                    <div class="ml-2 self-center text-center">
                        <h1 class="text-white text-[15px] mb-1">USER</h1>
                        <h1 class="text-[10px] text-white">Staff</h1>
                    </div>
                </div>
                <!-- logout button -->
                <a href="#"
                    class="flex text-red-400 border border-red-500 rounded-[14px] justify-center mt-4 mb-4 p-1 duration-300 transition-all hover:bg-red-500 hover:text-black">
                    Logout
                </a>
            </div>
        </div>
    </section>
</body>
</html>