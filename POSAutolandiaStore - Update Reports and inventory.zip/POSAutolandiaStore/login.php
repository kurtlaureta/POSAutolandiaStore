<?php
session_start();
include "db.php";

/* LOGOUT HANDLER */
if (isset($_GET['logout']) && $_GET['logout'] == '1') {
    if (isset($_SESSION["user_id"])) {
        $userId = (int) $_SESSION["user_id"];

        $stmt = $conn->prepare("
            UPDATE users
            SET status = 'offline', last_activity = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
    }

    session_unset();
    session_destroy();
    session_start();
}

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = trim($_POST["password"] ?? "");

    if ($username === "" || $password === "") {
        $message = "Please enter your username and password.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $isValidPassword = false;

        if ($user) {
            if (password_verify($password, $user["password"])) {
                $isValidPassword = true;
            } elseif ($password === $user["password"]) {
                $isValidPassword = true;

                // auto-convert plain text password to hashed password after successful login
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $upgrade = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $upgrade->bind_param("si", $newHash, $user["id"]);
                $upgrade->execute();
            }
        }

        if ($user && $isValidPassword) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["full_name"] = $user["full_name"] ?? "";
            $_SESSION["role"] = $user["role"] ?? "staff";

            $update = $conn->prepare("
                UPDATE users
                SET status = 'online', last_activity = NOW()
                WHERE id = ?
            ");
            $update->bind_param("i", $user["id"]);
            $update->execute();

            header("Location: home.php");
            exit;
        } else {
            $message = "Invalid username or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Document</title>
    <style type="text/tailwindcss">
        h3{
            @apply font-bold text-orange-400;
        }
        * {
            caret-color: transparent;
        }

        input[type="text"],
        input[type="search"],
        input[type="password"],
        input[type="email"],
        input[type="number"],
        textarea,
        [contenteditable="true"] {
            caret-color: auto;
        }
    </style>
</head>
<body>
    <!-- credits and info card -->
    <section class="bg-gray-100 h-screen w-screen flex items-center justify-center">
        <!-- info card -->
        <div class="bg-gradient-to-br from-gray-800 to-gray-900 h-120 w-[400px] shadow-md shadow-gray-400 flex items-center flex-col p-8">
            <div>
                <div class="flex justify-center m-4">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6 text-orange-500 mr-1">
                        <path fill-rule="evenodd" d="M7.5 6v.75H5.513c-.96 0-1.764.724-1.865 1.679l-1.263 12A1.875 1.875 0 0 0 4.25 22.5h15.5a1.875 1.875 0 0 0 1.865-2.071l-1.263-12a1.875 1.875 0 0 0-1.865-1.679H16.5V6a4.5 4.5 0 1 0-9 0ZM12 3a3 3 0 0 0-3 3v.75h6V6a3 3 0 0 0-3-3Zm-3 8.25a3 3 0 1 0 6 0v-.75a.75.75 0 0 1 1.5 0v.75a4.5 4.5 0 1 1-9 0v-.75a.75.75 0 0 1 1.5 0v.75Z" clip-rule="evenodd" />
                    </svg>

                    <h1 class="font-bold text-[20px] text-white">ANNA MART</h1>
                </div>
               <h1 class="font-extrabold text-3xl text-center text-white"> <span class="bg-clip-text bg-gradient-to-r from-orange-500 to-orange-700 text-transparent">Manage and Process</span> sales in your business. </h1>
               <p class="text-[14px] text-gray-300 text-center mt-8">Efficiently handle transactions, monitor orders, export sales records, and organize product details with just one click.</p>
                <div class="grid grid-cols-3 w-auto h-auto justify-center px-10 py-6 gap-2 border-b border-b-gray-700">
                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-orange-500">
                            <path d="M2.25 2.25a.75.75 0 0 0 0 1.5h1.386c.17 0 .318.114.362.278l2.558 9.592a3.752 3.752 0 0 0-2.806 3.63c0 .414.336.75.75.75h15.75a.75.75 0 0 0 0-1.5H5.378A2.25 2.25 0 0 1 7.5 15h11.218a.75.75 0 0 0 .674-.421 60.358 60.358 0 0 0 2.96-7.228.75.75 0 0 0-.525-.965A60.864 60.864 0 0 0 5.68 4.509l-.232-.867A1.875 1.875 0 0 0 3.636 2.25H2.25ZM3.75 20.25a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM16.5 20.25a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0Z" />
                        </svg>
                            <p class="mt-1 text-[12px] font-extralight text-gray-300">SALES</p>
                    </div>
                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-orange-500">
                            <path fill-rule="evenodd" d="M19.5 21a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3h-5.379a.75.75 0 0 1-.53-.22L11.47 3.66A2.25 2.25 0 0 0 9.879 3H4.5a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h15Zm-6.75-10.5a.75.75 0 0 0-1.5 0v4.19l-1.72-1.72a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l3-3a.75.75 0 1 0-1.06-1.06l-1.72 1.72V10.5Z" clip-rule="evenodd" />
                        </svg>
                            <p class="mt-1 text-[12px] font-extralight text-gray-300">INVENTORY</p>
                    </div>
                    <div class="border flex flex-col items-center p-2 rounded-sm border-gray-700 bg-gray-800 duration-100 transition-all hover:scale-105 cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 text-orange-500">
                            <path fill-rule="evenodd" d="M7.502 6h7.128A3.375 3.375 0 0 1 18 9.375v9.375a3 3 0 0 0 3-3V6.108c0-1.505-1.125-2.811-2.664-2.94a48.972 48.972 0 0 0-.673-.05A3 3 0 0 0 15 1.5h-1.5a3 3 0 0 0-2.663 1.618c-.225.015-.45.032-.673.05C8.662 3.295 7.554 4.542 7.502 6ZM13.5 3A1.5 1.5 0 0 0 12 4.5h4.5A1.5 1.5 0 0 0 15 3h-1.5Z" clip-rule="evenodd" />
                            <path fill-rule="evenodd" d="M3 9.375C3 8.339 3.84 7.5 4.875 7.5h9.75c1.036 0 1.875.84 1.875 1.875v11.25c0 1.035-.84 1.875-1.875 1.875h-9.75A1.875 1.875 0 0 1 3 20.625V9.375ZM6 12a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V12Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 15a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V15Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75ZM6 18a.75.75 0 0 1 .75-.75h.008a.75.75 0 0 1 .75.75v.008a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V18Zm2.25 0a.75.75 0 0 1 .75-.75h3.75a.75.75 0 0 1 0 1.5H9a.75.75 0 0 1-.75-.75Z" clip-rule="evenodd" />
                        </svg>
                            <p class="mt-1 text-[12px] font-extralight text-gray-300">REPORTS</p>
                    </div>
                </div>
                <div class="px-2 mt-3">
                    <p class="text-[10px] font-extralight text-gray-300">CREATED BY</p>
                    <p class="text-[12px] font-bold text-orange-400">KURT BRYAN V. LAURETA & RAVEN BLAIR D. NOBLEZA</p>
                    <p class="text-[10px] font-extralight text-gray-300">© 2026 INTERN · All rights reserved.</p>
                </div>
            </div>  
        </div>

        <!-- login card -->
        <div class="bg-white h-120 shadow-md shadow-gray-400 flex items-center flex-col p-8">
            <div>
                <h1 class="font-bold text-2xl mt-6 text-orange-600">Welcome to Autolandia Store</h1>
                <p class="font-medium text-[13px] text-center text-gray-600">Sign-in to your user account</p>

                <?php if ($message): ?>
                    <div class="mt-4 w-full rounded-xl bg-red-100 border border-red-200 text-red-700 px-4 py-3 text-sm font-medium">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="mt-8">
                    <h3>USERNAME</h3>
                    <div class="relative">
                        <input
                            type="text"
                            name="username"
                            placeholder="Enter your username"
                            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                            class="border w-full px-12 py-3 rounded-2xl border-gray-300 bg-gray-300 focus:border-orange-500 focus:outline-none focus:ring-orange-500 focus:ring-1"
                            required
                        >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="absolute top-1/2 left-4 size-5 transform -translate-y-1/2 text-black pointer-events-none">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                        </svg>
                    </div>

                    <h3 class="mt-2">PASSWORD</h3>
                    <div class="relative">
                        <input
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            class="border w-full px-12 py-3 rounded-2xl border-gray-300 bg-gray-300 focus:border-orange-500 focus:outline-none focus:ring-orange-500 focus:ring-1"
                            required
                        >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5 absolute top-1/2 left-4 transform -translate-y-1/2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
                        </svg>
                    </div>

                    <button
                        type="submit"
                        class="w-full border mt-6 p-2 rounded-4xl bg-gradient-to-r from-orange-500 to-orange-700 border-orange-500 text-white font-bold cursor-pointer hover:bg-gradient-to-r hover:from-white hover:to-white hover:text-orange-600"
                    >
                        LOGIN
                    </button>
                </form>
            </div>  
        </div>
    </section>
</body>
</html>