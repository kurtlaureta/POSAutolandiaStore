<?php
include "db.php";

$view = $_GET['view'] ?? 'summary';
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to   = $_GET['date_to'] ?? date('Y-m-d');

$startDateTime = $date_from . ' 00:00:00';
$endDateTime   = $date_to . ' 23:59:59';

$allowedViews = ['summary', 'items', 'categories', 'payments', 'receipts'];
if (!in_array($view, $allowedViews, true)) {
    $view = 'summary';
}

$filename = 'POS_Report_' . $view . '_' . $date_from . '_to_' . $date_to . '.xls';

header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

echo "<html>";
echo "<head><meta charset='UTF-8'></head>";
echo "<body>";
echo "<table border='1'>";
echo "<tr><th colspan='10' style='font-size:16px;'>POS Reports Export</th></tr>";
echo "<tr><th colspan='10'>View: " . htmlspecialchars(ucfirst($view)) . "</th></tr>";
echo "<tr><th colspan='10'>Date Range: " . htmlspecialchars($date_from) . " to " . htmlspecialchars($date_to) . "</th></tr>";
echo "<tr></tr>";

if ($view === 'summary') {
    $stmt = $conn->prepare("
        SELECT
            DATE(created_at) AS sales_date,
            COUNT(*) AS receipts,
            COALESCE(SUM(total_amount), 0) AS gross_sales,
            COALESCE(AVG(total_amount), 0) AS avg_sale
        FROM transactions
        WHERE created_at BETWEEN ? AND ?
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) DESC
    ");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<tr>";
    echo "<th>Date</th>";
    echo "<th>Receipts</th>";
    echo "<th>Gross Sales</th>";
    echo "<th>Average Sale</th>";
    echo "</tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['sales_date']) . "</td>";
        echo "<td>" . (int)$row['receipts'] . "</td>";
        echo "<td>" . number_format((float)$row['gross_sales'], 2, '.', '') . "</td>";
        echo "<td>" . number_format((float)$row['avg_sale'], 2, '.', '') . "</td>";
        echo "</tr>";
    }

} elseif ($view === 'items') {
    $stmt = $conn->prepare("
        SELECT
            ti.product_name,
            COALESCE(c.category_name, 'Uncategorized') AS category_name,
            COALESCE(SUM(ti.qty), 0) AS items_sold,
            COALESCE(SUM(ti.subtotal), 0) AS net_sales,
            COALESCE(AVG(ti.price), 0) AS avg_price
        FROM transaction_items ti
        LEFT JOIN products p ON ti.product_id = p.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE ti.created_at BETWEEN ? AND ?
        GROUP BY ti.product_id, ti.product_name, c.category_name
        ORDER BY net_sales DESC, items_sold DESC
    ");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<tr>";
    echo "<th>Item</th>";
    echo "<th>Category</th>";
    echo "<th>Items Sold</th>";
    echo "<th>Net Sales</th>";
    echo "<th>Average Price</th>";
    echo "</tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['category_name']) . "</td>";
        echo "<td>" . (int)$row['items_sold'] . "</td>";
        echo "<td>" . number_format((float)$row['net_sales'], 2, '.', '') . "</td>";
        echo "<td>" . number_format((float)$row['avg_price'], 2, '.', '') . "</td>";
        echo "</tr>";
    }

} elseif ($view === 'categories') {
    $stmt = $conn->prepare("
        SELECT
            COALESCE(c.category_name, 'Uncategorized') AS category_name,
            COALESCE(SUM(ti.qty), 0) AS items_sold,
            COALESCE(SUM(ti.subtotal), 0) AS net_sales
        FROM transaction_items ti
        LEFT JOIN products p ON ti.product_id = p.id
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE ti.created_at BETWEEN ? AND ?
        GROUP BY c.category_name
        ORDER BY net_sales DESC, items_sold DESC
    ");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<tr>";
    echo "<th>Category</th>";
    echo "<th>Items Sold</th>";
    echo "<th>Net Sales</th>";
    echo "</tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['category_name']) . "</td>";
        echo "<td>" . (int)$row['items_sold'] . "</td>";
        echo "<td>" . number_format((float)$row['net_sales'], 2, '.', '') . "</td>";
        echo "</tr>";
    }

} elseif ($view === 'payments') {
    $stmt = $conn->prepare("
        SELECT
            COUNT(*) AS payment_transactions,
            COALESCE(SUM(total_amount), 0) AS payment_amount
        FROM transactions
        WHERE created_at BETWEEN ? AND ?
    ");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    echo "<tr>";
    echo "<th>Payment Type</th>";
    echo "<th>Transactions</th>";
    echo "<th>Amount</th>";
    echo "<th>Refunds</th>";
    echo "<th>Net Amount</th>";
    echo "</tr>";

    echo "<tr>";
    echo "<td>Cash</td>";
    echo "<td>" . (int)($row['payment_transactions'] ?? 0) . "</td>";
    echo "<td>" . number_format((float)($row['payment_amount'] ?? 0), 2, '.', '') . "</td>";
    echo "<td>0.00</td>";
    echo "<td>" . number_format((float)($row['payment_amount'] ?? 0), 2, '.', '') . "</td>";
    echo "</tr>";

} elseif ($view === 'receipts') {
    $stmt = $conn->prepare("
        SELECT
            receipt_no,
            created_at,
            total_amount,
            cash_amount,
            change_amount
        FROM transactions
        WHERE created_at BETWEEN ? AND ?
        ORDER BY created_at DESC
    ");
    $stmt->bind_param("ss", $startDateTime, $endDateTime);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<tr>";
    echo "<th>Receipt No.</th>";
    echo "<th>Date</th>";
    echo "<th>Amount</th>";
    echo "<th>Cash</th>";
    echo "<th>Change</th>";
    echo "</tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['receipt_no']) . "</td>";
        echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
        echo "<td>" . number_format((float)$row['total_amount'], 2, '.', '') . "</td>";
        echo "<td>" . number_format((float)$row['cash_amount'], 2, '.', '') . "</td>";
        echo "<td>" . number_format((float)$row['change_amount'], 2, '.', '') . "</td>";
        echo "</tr>";
    }
}

echo "</table>";
echo "</body>";
echo "</html>";
exit;
?>