<?php
include "db.php";

$transaction_id = (int)($_GET["transaction_id"] ?? 0);
$transaction = null;

if ($transaction_id > 0) {
    $stmtTxn = $conn->prepare("SELECT * FROM transactions WHERE id = ? LIMIT 1");
    $stmtTxn->bind_param("i", $transaction_id);
    $stmtTxn->execute();
    $transaction = $stmtTxn->get_result()->fetch_assoc();

    $stmt = $conn->prepare("
        SELECT * 
        FROM transaction_items
        WHERE transaction_id = ?
        ORDER BY id DESC
    ");
    $stmt->bind_param("i", $transaction_id);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT * FROM transaction_items ORDER BY id DESC";
    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Items</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-7xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
                <h1 class="text-2xl font-bold text-orange-500">Transaction Items</h1>
                <?php if ($transaction): ?>
                    <p class="text-gray-500">
                        Items for Receipt: <span class="font-semibold"><?= htmlspecialchars($transaction['receipt_no']) ?></span>
                    </p>
                <?php else: ?>
                    <p class="text-gray-500">All sold items from all transactions.</p>
                <?php endif; ?>
            </div>

            <div class="flex gap-2">
                <?php if ($transaction): ?>
                    <a href="transactions.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                        Back to Transactions
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($transaction): ?>
            <div class="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <p class="text-sm text-gray-500">Receipt No</p>
                    <p class="font-bold text-orange-500"><?= htmlspecialchars($transaction['receipt_no']) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Total</p>
                    <p class="font-bold">₱<?= number_format((float)$transaction['total_amount'], 2) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Cash</p>
                    <p class="font-bold">₱<?= number_format((float)$transaction['cash_amount'], 2) ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Change</p>
                    <p class="font-bold">₱<?= number_format((float)$transaction['change_amount'], 2) ?></p>
                </div>
            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-orange-100 text-left">
                        <th class="p-3">ID</th>
                        <th class="p-3">Transaction ID</th>
                        <th class="p-3">Barcode</th>
                        <th class="p-3">Product Name</th>
                        <th class="p-3">Price</th>
                        <th class="p-3">Qty</th>
                        <th class="p-3">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-b hover:bg-orange-50">
                                <td class="p-3 font-medium"><?= (int)$row['id'] ?></td>
                                <td class="p-3"><?= (int)$row['transaction_id'] ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['barcode'] ?: 'N/A') ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['product_name']) ?></td>
                                <td class="p-3">₱<?= number_format((float)$row['price'], 2) ?></td>
                                <td class="p-3"><?= (int)$row['qty'] ?></td>
                                <td class="p-3 font-semibold">₱<?= number_format((float)$row['subtotal'], 2) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="p-6 text-center text-gray-500">No transaction items found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>