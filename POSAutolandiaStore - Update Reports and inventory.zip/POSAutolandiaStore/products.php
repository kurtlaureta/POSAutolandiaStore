<?php
session_start();
include "db.php";

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

foreach ($_SESSION['cart'] as $key => $item) {
    if (!isset($_SESSION['cart'][$key]['cart_key'])) {
        $_SESSION['cart'][$key]['cart_key'] = $key;
    }
}

$message = "";
$success = false;
$showReceiptModal = false;
$receiptData = null;

/* IMAGE UPDATE */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_product_image"])) {
    $product_id = (int)($_POST["product_id"] ?? 0);

    if ($product_id <= 0) {
        $message = "Invalid product.";
    } elseif (!isset($_FILES["product_image"]) || $_FILES["product_image"]["error"] !== 0) {
        $message = "Please choose an image first.";
    } else {
        $uploadDir = "uploads/";

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileTmpPath = $_FILES["product_image"]["tmp_name"];
        $fileName = $_FILES["product_image"]["name"];
        $fileSize = $_FILES["product_image"]["size"];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        $allowedExt = ["jpg", "jpeg", "png", "gif", "webp"];

        if (!in_array($fileExt, $allowedExt)) {
            $message = "Invalid image file type.";
        } elseif ($fileSize > 5 * 1024 * 1024) {
            $message = "Image file is too large. Maximum size is 5MB.";
        } else {
            $newFileName = "product_" . time() . "_" . uniqid() . "." . $fileExt;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $stmt = $conn->prepare("UPDATE products SET product_image = ? WHERE id = ?");
                $stmt->bind_param("si", $destPath, $product_id);

                if ($stmt->execute()) {
                    $message = "Product image updated successfully.";
                    $success = true;
                } else {
                    $message = "Failed to update image.";
                }
            } else {
                $message = "Failed to upload image.";
            }
        }
    }
}

/* REUSABLE FUNCTION */
function addToCartByProduct($product, $barcode, &$message)
{
    $product_id = (int)$product['id'];
    $availableStock = (int)$product["stock_qty"];

    if ($availableStock <= 0) {
        $message = "Product is out of stock.";
        return;
    }

    $cartKey = 'product_' . $product_id;

    $currentQtyInCart = isset($_SESSION['cart'][$cartKey]) ? (int)$_SESSION['cart'][$cartKey]['qty'] : 0;

    if ($currentQtyInCart >= $availableStock) {
        $message = "Cannot add more. Cart quantity already reached available stock.";
        return;
    }

    if (isset($_SESSION['cart'][$cartKey])) {
        $_SESSION['cart'][$cartKey]['qty'] += 1;
        $_SESSION['cart'][$cartKey]['stock_qty'] = $availableStock;
        $message = $product['product_name'] . " quantity updated in cart.";
    } else {
        $_SESSION['cart'][$cartKey] = [
            'product_id' => $product['id'],
            'barcode' => $barcode,
            'cart_key' => $cartKey,
            'product_name' => $product['product_name'],
            'category_name' => $product['category_name'] ?? 'Uncategorized',
            'price' => $product['price'],
            'qty' => 1,
            'stock_qty' => $availableStock
        ];
        $message = $product['product_name'] . " added to cart.";
    }
}

/* ADD TO CART BY BUTTON */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_to_cart"])) {
    $product_id = (int)($_POST["product_id"] ?? 0);

    $stmt = $conn->prepare("
        SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $barcodeStmt = $conn->prepare("
            SELECT barcode
            FROM product_barcodes
            WHERE product_id = ? AND is_sold = 0
            LIMIT 1
        ");
        $barcodeStmt->bind_param("i", $product_id);
        $barcodeStmt->execute();
        $barcodeResult = $barcodeStmt->get_result();
        $barcodeRow = $barcodeResult->fetch_assoc();

        $sampleBarcode = $barcodeRow['barcode'] ?? '';
        addToCartByProduct($product, $sampleBarcode, $message);
    } else {
        $message = "Product not found.";
    }
}

/* ADD TO CART BY BARCODE SCAN / INPUT */
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["scan_barcode"])) {
    $barcodeInput = trim($_GET["search"] ?? "");
    $view = trim($_GET["view"] ?? "all");

    if ($barcodeInput !== "") {
        $stmt = $conn->prepare("
            SELECT pb.barcode, p.*, c.category_name
            FROM product_barcodes pb
            INNER JOIN products p ON pb.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE pb.barcode = ? AND pb.is_sold = 0
            LIMIT 1
        ");
        $stmt->bind_param("s", $barcodeInput);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        if ($product) {
            addToCartByProduct($product, $product['barcode'], $message);
            $_SESSION['flash_message'] = $message;
            header("Location: products.php?view=" . urlencode($view));
            exit;
        } else {
            $message = "Barcode not found. Showing search results instead.";
        }
    }
}

/* FLASH MESSAGE */
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}

if (!$showReceiptModal && isset($_SESSION['last_receipt'])) {
    $receiptData = $_SESSION['last_receipt'];
}

/* UPDATE CART QTY */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_qty"])) {
    $cart_key = trim($_POST["cart_key"] ?? "");
    $qty = (int)($_POST["qty"] ?? 1);

    if (isset($_SESSION['cart'][$cart_key])) {
        $availableStock = (int)($_SESSION['cart'][$cart_key]['stock_qty'] ?? 0);

        if ($qty <= 0) {
            unset($_SESSION['cart'][$cart_key]);
            $message = "Item removed from cart.";
            $success = true;
        } else {
            if ($availableStock > 0 && $qty > $availableStock) {
                $_SESSION['cart'][$cart_key]['qty'] = $availableStock;
                $message = "Quantity adjusted to available stock only.";
            } else {
                $_SESSION['cart'][$cart_key]['qty'] = $qty;
                $message = "Cart quantity updated.";
                $success = true;
            }
        }
    }
}

/* REMOVE ITEM */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["remove_item"])) {
    $cart_key = trim($_POST["cart_key"] ?? "");

    if ($cart_key !== "" && isset($_SESSION['cart'][$cart_key])) {
        unset($_SESSION['cart'][$cart_key]);
        $message = "Item removed from cart.";
        $success = true;
    }
}

/* CHECKOUT */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["checkout"])) {
    $cash = (float)($_POST["cash_amount"] ?? 0);

    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['qty'];
    }

    if ($total <= 0) {
        $message = "Cart is empty.";
    } elseif ($cash < $total) {
        $message = "Cash amount cannot be less than the total price.";
    } else {
        $receiptNo = "RCPT-" . date("YmdHis");
        $change = $cash - $total;

        $conn->begin_transaction();

        try {
            $stmt = $conn->prepare("
                INSERT INTO transactions (receipt_no, total_amount, cash_amount, change_amount)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param("sddd", $receiptNo, $total, $cash, $change);
            $stmt->execute();
            $transactionId = $conn->insert_id;

            $receiptItems = [];

            foreach ($_SESSION['cart'] as $item) {
                $productId = (int)$item['product_id'];
                $barcode = trim($item['barcode'] ?? '');
                $qty = (int)$item['qty'];
                $subtotal = $item['price'] * $qty;

                $stmtItem = $conn->prepare("
                    INSERT INTO transaction_items (transaction_id, product_id, barcode, product_name, price, qty, subtotal)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtItem->bind_param(
                    "iissdid",
                    $transactionId,
                    $productId,
                    $barcode,
                    $item['product_name'],
                    $item['price'],
                    $qty,
                    $subtotal
                );
                $stmtItem->execute();

                $deductStock = $conn->prepare("
                    UPDATE products
                    SET stock_qty = stock_qty - ?
                    WHERE id = ? AND stock_qty >= ?
                ");
                $deductStock->bind_param("iii", $qty, $productId, $qty);
                $deductStock->execute();

                if ($deductStock->affected_rows <= 0) {
                    throw new Exception("Insufficient stock for " . $item['product_name']);
                }

                if ($barcode !== '') {
                    $remainingToMark = $qty;

                    $barcodeRowsStmt = $conn->prepare("
                        SELECT id
                        FROM product_barcodes
                        WHERE product_id = ? AND is_sold = 0
                        LIMIT ?
                    ");
                    $barcodeRowsStmt->bind_param("ii", $productId, $remainingToMark);
                    $barcodeRowsStmt->execute();
                    $barcodeRowsResult = $barcodeRowsStmt->get_result();

                    $barcodeIds = [];
                    while ($barcodeRow = $barcodeRowsResult->fetch_assoc()) {
                        $barcodeIds[] = (int)$barcodeRow['id'];
                    }

                    if (count($barcodeIds) > 0) {
                        $idList = implode(",", $barcodeIds);
                        $conn->query("UPDATE product_barcodes SET is_sold = 1 WHERE id IN ($idList)");
                    }
                }

                $receiptItems[] = [
                    'product_name' => $item['product_name'],
                    'barcode' => $barcode,
                    'price' => $item['price'],
                    'qty' => $qty,
                    'subtotal' => $subtotal
                ];
            }

            $conn->commit();

            $receiptData = [
                'receipt_no' => $receiptNo,
                'transaction_id' => $transactionId,
                'items' => $receiptItems,
                'total' => $total,
                'cash' => $cash,
                'change' => $change,
                'date' => date("Y-m-d h:i A")
            ];

            $_SESSION['last_receipt'] = $receiptData;
            $_SESSION['cart'] = [];

            $message = "Checkout successful.";
            $success = true;
            $showReceiptModal = true;
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Checkout failed: " . $e->getMessage();
        }
    }
}

/* SEARCH + VIEW MODE */
$search = trim($_GET["search"] ?? "");
$view = trim($_GET["view"] ?? "all");

if ($search !== "") {
    $sql = "
        SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.product_name LIKE ?
           OR c.category_name LIKE ?
        ORDER BY c.category_name ASC, p.product_name ASC
    ";
    $stmt = $conn->prepare($sql);
    $like = "%" . $search . "%";
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $products = $stmt->get_result();
} else {
    $sql = "
        SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        ORDER BY c.category_name ASC, p.product_name ASC
    ";
    $products = $conn->query($sql);
}

/* GROUP PRODUCTS BY CATEGORY */
$groupedProducts = [];
$allProducts = [];

if ($products && $products->num_rows > 0) {
    while ($row = $products->fetch_assoc()) {
        $categoryName = !empty($row['category_name']) ? $row['category_name'] : 'Uncategorized';
        $groupedProducts[$categoryName][] = $row;
        $allProducts[] = $row;
    }
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['qty'];
}

function renderProductCard($row)
{
?>
    <div class="bg-white rounded-2xl shadow-sm overflow-hidden border border-orange-100 hover:shadow-md transition">
        <div class="h-40 bg-orange-100 flex items-center justify-center overflow-hidden">
            <?php if (!empty($row['product_image']) && file_exists($row['product_image'])): ?>
                <img 
                    src="<?= htmlspecialchars($row['product_image']) ?>" 
                    alt="<?= htmlspecialchars($row['product_name']) ?>"
                    class="w-full h-full object-cover"
                >
            <?php else: ?>
                <div class="w-full h-full flex flex-col items-center justify-center gap-2 p-3">
                    <span class="text-orange-400 font-bold text-sm">NO IMAGE</span>

                    <form method="POST" enctype="multipart/form-data" class="w-full flex flex-col gap-2">
                        <input type="hidden" name="product_id" value="<?= (int)$row['id'] ?>">
                        <input type="file" name="product_image" accept="image/*" class="text-xs w-full bg-white border rounded-lg px-2 py-1">
                        <button type="submit" name="update_product_image" class="bg-orange-400 hover:bg-orange-500 text-white text-xs py-1 rounded-lg font-semibold cursor-pointer">
                            Upload Image
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>

        <div class="p-4 space-y-2">
            <h2 class="font-bold text-lg text-gray-800 line-clamp-2">
                <?= htmlspecialchars($row['product_name']) ?>
            </h2>

            <p class="text-sm text-gray-500">
                Category: <?= htmlspecialchars($row['category_name'] ?? 'Uncategorized') ?>
            </p>

            <div class="flex items-center justify-between">
                <p class="text-orange-500 font-bold text-lg">
                    ₱<?= number_format($row['price'], 2) ?>
                </p>
                <p class="text-sm font-medium <?= ((int)$row['stock_qty'] > 0) ? 'text-green-600' : 'text-red-500' ?>">
                    Stock: <?= (int)$row['stock_qty'] ?>
                </p>
            </div>

            <form method="POST">
                <input type="hidden" name="product_id" value="<?= (int)$row['id'] ?>">
                <button 
                    type="submit" 
                    name="add_to_cart"
                    class="w-full mt-2 bg-orange-400 hover:bg-orange-500 text-white py-2 rounded-xl font-semibold disabled:bg-gray-300 disabled:cursor-not-allowed"
                    <?= ((int)$row['stock_qty'] <= 0) ? 'disabled' : '' ?>
                >
                    <?= ((int)$row['stock_qty'] <= 0) ? 'Out of Stock' : 'Add to Cart' ?>
                </button>
            </form>
        </div>
    </div>
<?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        @media print {
            body * {
                visibility: hidden !important;
            }

            #receiptModal,
            #receiptModal * {
                visibility: visible !important;
            }

            #receiptModal {
                position: absolute !important;
                inset: 0 !important;
                width: 100% !important;
                height: auto !important;
                padding: 0 !important;
                margin: 0 !important;
                display: block !important;
                background: white !important;
            }

            #receiptModal > div {
                width: 100% !important;
                max-width: 100% !important;
                border: none !important;
                border-radius: 0 !important;
                box-shadow: none !important;
                margin: 0 !important;
            }

            #receiptOverlay,
            #closeReceiptModal,
            #doneReceiptModal {
                display: none !important;
            }
        }
        * {
            caret-color: transparent;
        }

        input[type="text"],
        input[type="search"],
        input[type="password"],
        input[type="email"],
        input[type="number"],
        textarea,
        [contenteditable="true"] {
            caret-color: auto;
        }
    </style>
</head>
<body class="overflow-x-hidden bg-orange-50">
    <?php include 'navbar.php'; ?>

    <main class="ml-69 mt-24 min-h-screen p-4">
        <div class="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-4">

            <section class="w-full">
                <div class="w-full bg-white shadow-sm p-4 rounded-2xl flex flex-col gap-4 mb-4">
                    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <p class="font-bold text-xl text-orange-500">PRODUCTS</p>

                        <form method="GET" class="relative border border-gray-200 shadow-sm px-8 py-2 rounded-[0.55rem] bg-white hover:border-orange-300">
                            <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 absolute left-1 top-1/2 -translate-y-1/2 ml-1 text-gray-500">
                                <path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd" />
                            </svg>
                            <input 
                                type="text" 
                                name="search"
                                value="<?= htmlspecialchars($search) ?>"
                                placeholder="Search or scan barcode..." 
                                class="outline-0 font-medium w-72"
                                autofocus
                            >
                            <button type="submit" name="scan_barcode" value="1" class="hidden"></button>
                        </form>
                    </div>

                    <div class="flex justify-center gap-3">
                        <a href="products.php?view=all<?= $search !== '' ? '&search=' . urlencode($search) : '' ?>"
                           class="px-4 py-2 rounded-xl font-semibold border transition <?= $view === 'all' ? 'bg-orange-400 text-white border-orange-400' : 'bg-white text-orange-500 border-orange-300 hover:bg-orange-50' ?>">
                            All Products Grid
                        </a>

                        <a href="products.php?view=category<?= $search !== '' ? '&search=' . urlencode($search) : '' ?>"
                           class="px-4 py-2 rounded-xl font-semibold border transition <?= $view === 'category' ? 'bg-orange-400 text-white border-orange-400' : 'bg-white text-orange-500 border-orange-300 hover:bg-orange-50' ?>">
                            Categories Grid View
                        </a>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?> font-medium">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($allProducts)): ?>
                    <?php if ($view === 'category'): ?>
                        <div class="space-y-8">
                            <?php foreach ($groupedProducts as $categoryName => $categoryItems): ?>
                                <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-4">
                                    <div class="flex items-center justify-between mb-4">
                                        <h2 class="text-xl font-bold text-orange-500">
                                            <?= htmlspecialchars($categoryName) ?>
                                        </h2>
                                        <span class="text-sm bg-orange-100 text-orange-600 px-3 py-1 rounded-full font-medium">
                                            <?= count($categoryItems) ?> product<?= count($categoryItems) > 1 ? 's' : '' ?>
                                        </span>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4">
                                        <?php foreach ($categoryItems as $row): ?>
                                            <?php renderProductCard($row); ?>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4">
                            <?php foreach ($allProducts as $row): ?>
                                <?php renderProductCard($row); ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="col-span-full bg-white rounded-2xl shadow-sm p-10 text-center text-gray-500 font-medium">
                        No products found in inventory.
                    </div>
                <?php endif; ?>
            </section>

            <aside class="w-full">
                <div class="bg-white rounded-2xl shadow-sm p-4 sticky top-24">
                    <div class="border-b pb-3 mb-3">
                        <h2 class="text-xl font-bold text-orange-500">Invoice Queue</h2>
                        <p class="text-sm text-gray-500">Selected items will appear here.</p>
                    </div>

                    <div class="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                                <div class="border border-orange-100 rounded-xl p-3">
                                    <div class="flex items-start justify-between gap-2">
                                        <div>
                                            <p class="font-bold text-gray-800">
                                                <?= htmlspecialchars($item['product_name']) ?>
                                            </p>
                                            <p class="text-sm text-gray-500">
                                                Barcode: <?= htmlspecialchars($item['barcode'] ?? 'N/A') ?>
                                            </p>
                                            <p class="text-sm text-gray-500">
                                                ₱<?= number_format($item['price'], 2) ?> each
                                            </p>
                                        </div>

                                        <form method="POST">
                                            <input type="hidden" name="cart_key" value="<?= htmlspecialchars($item['cart_key'] ?? ($item['barcode'] ?? '')) ?>">
                                            <button type="submit" name="remove_item" class="text-red-500 hover:text-red-700 font-bold text-sm cursor-pointer">
                                                Remove
                                            </button>
                                        </form>
                                    </div>

                                    <div class="mt-3 flex items-center justify-between gap-2">
                                        <form method="POST" class="cart-qty-form flex items-center gap-2">
                                            <input type="hidden" name="cart_key" value="<?= htmlspecialchars($item['cart_key'] ?? ($item['barcode'] ?? '')) ?>">
                                            <input type="hidden" name="update_qty" value="1">

                                            <button type="button" class="qty-minus bg-gray-200 hover:bg-gray-300 text-gray-700 w-8 h-8 rounded-lg font-bold cursor-pointer">
                                                -
                                            </button>

                                            <input
                                                type="number"
                                                name="qty"
                                                min="1"
                                                max="<?= (int)$item['stock_qty'] ?>"
                                                value="<?= (int)$item['qty'] ?>"
                                                class="cart-qty-input w-20 border rounded-lg px-2 py-1 text-center"
                                            >

                                            <button type="button" class="qty-plus bg-orange-400 hover:bg-orange-500 text-white w-8 h-8 rounded-lg font-bold cursor-pointer">
                                                +
                                            </button>
                                        </form>

                                        <p class="font-bold text-orange-500">
                                            ₱<?= number_format($item['price'] * $item['qty'], 2) ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center text-gray-500 py-10">
                                No items in cart yet.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="border-t mt-4 pt-4 space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="font-medium text-gray-700">Total</span>
                            <span class="text-2xl font-bold text-orange-500">₱<?= number_format($total, 2) ?></span>
                        </div>

                        <form method="POST" class="space-y-3">
                            <div>
                                <label class="block font-medium mb-1">Cash Amount</label>
                                <input type="number" step="0.01" name="cash_amount" class="w-full border rounded-xl px-4 py-2" required>
                            </div>

                            <button type="submit" name="checkout" class="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-bold cursor-pointer">
                                Checkout
                            </button>
                        </form>
                    </div>
                </div>
            </aside>
        </div>
    </main>

    <div id="receiptOverlay" class="fixed inset-0 bg-black/40 z-50 <?= $showReceiptModal ? '' : 'hidden' ?>"></div>

    <div id="receiptModal" class="fixed inset-0 z-50 <?= $showReceiptModal ? 'flex' : 'hidden' ?> items-center justify-center p-4">
        <div class="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-orange-200">
            <div class="flex items-center justify-between px-6 py-4 border-b bg-orange-50">
                <div>
                    <h2 class="text-2xl font-bold text-orange-500">Receipt</h2>
                    <p class="text-sm text-gray-500">Successful checkout record</p>
                </div>
                <button type="button" id="closeReceiptModal" class="bg-red-400 hover:bg-red-500 text-white px-4 py-2 rounded-xl font-semibold cursor-pointer">
                    X
                </button>
            </div>

            <div class="p-6 max-h-[80vh] overflow-y-auto">
                <?php if ($receiptData): ?>
                    <div class="space-y-2 mb-4">
                        <p><span class="font-bold">Receipt No:</span> <?= htmlspecialchars($receiptData['receipt_no']) ?></p>
                        <p><span class="font-bold">Date:</span> <?= htmlspecialchars($receiptData['date']) ?></p>
                        <p><span class="font-bold">Transaction ID:</span> <?= (int)$receiptData['transaction_id'] ?></p>
                    </div>

                    <div class="overflow-x-auto border rounded-xl">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-orange-100 text-left">
                                    <th class="p-3">Product</th>
                                    <th class="p-3">Barcode</th>
                                    <th class="p-3">Price</th>
                                    <th class="p-3">Qty</th>
                                    <th class="p-3">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($receiptData['items'] as $receiptItem): ?>
                                    <tr class="border-b">
                                        <td class="p-3"><?= htmlspecialchars($receiptItem['product_name']) ?></td>
                                        <td class="p-3"><?= htmlspecialchars($receiptItem['barcode'] ?: 'N/A') ?></td>
                                        <td class="p-3">₱<?= number_format($receiptItem['price'], 2) ?></td>
                                        <td class="p-3"><?= (int)$receiptItem['qty'] ?></td>
                                        <td class="p-3">₱<?= number_format($receiptItem['subtotal'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-6 space-y-2 text-right">
                        <p><span class="font-bold">Total:</span> ₱<?= number_format($receiptData['total'], 2) ?></p>
                        <p><span class="font-bold">Cash:</span> ₱<?= number_format($receiptData['cash'], 2) ?></p>
                        <p><span class="font-bold">Change:</span> ₱<?= number_format($receiptData['change'], 2) ?></p>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500">No receipt available.</p>
                <?php endif; ?>
            </div>

            <div class="px-6 py-4 border-t bg-gray-50 flex justify-end gap-3">
                <button type="button" id="printReceiptBtn" class="bg-orange-400 hover:bg-orange-500 text-white px-4 py-2 rounded-xl font-semibold cursor-pointer">
                    Print
                </button>
                <button type="button" id="doneReceiptModal" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl font-semibold cursor-pointer">
                    Done
                </button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.addEventListener('keydown', function(e) {
                if (e.key === 'Enter') {
                    this.form.submit();
                }
            });

            searchInput.addEventListener('input', function () {
                if (this.value.trim() === '') {
                    const viewInput = document.querySelector('input[name="view"]');
                    const view = viewInput ? viewInput.value : 'all';
                    window.location.href = 'products.php?view=' + encodeURIComponent(view);
                }
            });
        }

        const receiptModal = document.getElementById('receiptModal');
        const receiptOverlay = document.getElementById('receiptOverlay');
        const closeReceiptModal = document.getElementById('closeReceiptModal');
        const doneReceiptModal = document.getElementById('doneReceiptModal');
        const printReceiptBtn = document.getElementById('printReceiptBtn');

        function hideReceiptModal() {
            if (receiptModal) {
                receiptModal.classList.add('hidden');
                receiptModal.classList.remove('flex');
            }
            if (receiptOverlay) {
                receiptOverlay.classList.add('hidden');
            }
        }

        if (closeReceiptModal) {
            closeReceiptModal.addEventListener('click', hideReceiptModal);
        }

        if (doneReceiptModal) {
            doneReceiptModal.addEventListener('click', hideReceiptModal);
        }

        if (receiptOverlay) {
            receiptOverlay.addEventListener('click', hideReceiptModal);
        }

        if (printReceiptBtn) {
            printReceiptBtn.addEventListener('click', function () {
                window.print();
            });
        }

        document.querySelectorAll('.cart-qty-form').forEach(function(form) {
            const input = form.querySelector('.cart-qty-input');
            const minusBtn = form.querySelector('.qty-minus');
            const plusBtn = form.querySelector('.qty-plus');
            const min = parseInt(input.min || 1, 10);
            const max = parseInt(input.max || 999999, 10);
            let typingTimer;

            minusBtn.addEventListener('click', function() {
                let value = parseInt(input.value || min, 10);
                value = isNaN(value) ? min : value;
                value = value - 1;

                if (value <= 0) {
                    input.value = 0;
                } else {
                    input.value = value;
                }

                form.submit();
            });

            plusBtn.addEventListener('click', function() {
                let value = parseInt(input.value || min, 10);
                value = isNaN(value) ? min : value;
                value = value + 1;

                if (value > max) value = max;
                input.value = value;

                form.submit();
            });

            input.addEventListener('input', function() {
                clearTimeout(typingTimer);

                typingTimer = setTimeout(function() {
                    let value = parseInt(input.value || min, 10);

                    if (isNaN(value)) value = min;
                    if (value > max) value = max;
                    if (value < 0) value = 0;

                    input.value = value;
                    form.submit();
                }, 500);
            });

            input.addEventListener('change', function() {
                let value = parseInt(input.value || min, 10);

                if (isNaN(value)) value = min;
                if (value > max) value = max;
                if (value < 0) value = 0;

                input.value = value;
                form.submit();
            });
        });
    });
    </script>
</body>
</html>