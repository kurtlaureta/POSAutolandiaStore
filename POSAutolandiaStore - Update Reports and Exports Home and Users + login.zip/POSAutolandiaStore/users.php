<?php
session_start();
include "db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: home.php");
    exit;
}

$message = "";
$success = false;

/* CREATE USER - ADMIN ONLY */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["create_user"])) {
    $full_name = trim($_POST["full_name"] ?? "");
    $username  = trim($_POST["username"] ?? "");
    $password  = trim($_POST["password"] ?? "");
    $role      = trim($_POST["role"] ?? "staff");

    if ($full_name === "" || $username === "" || $password === "") {
        $message = "Please fill in all required fields.";
    } elseif (!in_array($role, ['admin', 'staff'], true)) {
        $message = "Invalid role selected.";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $check->bind_param("s", $username);
        $check->execute();
        $exists = $check->get_result()->fetch_assoc();

        if ($exists) {
            $message = "Username already exists.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("
                INSERT INTO users (full_name, username, password, role, status, created_at)
                VALUES (?, ?, ?, ?, 'offline', NOW())
            ");
            $stmt->bind_param("ssss", $full_name, $username, $hashedPassword, $role);

            if ($stmt->execute()) {
                $message = "User created successfully.";
                $success = true;
            } else {
                $message = "Failed to create user.";
            }
        }
    }
}

/* LOAD USERS */
$users = $conn->query("
    SELECT
        id,
        full_name,
        username,
        role,
        status,
        last_activity,
        created_at,
        CASE
            WHEN last_activity IS NOT NULL AND last_activity >= (NOW() - INTERVAL 5 MINUTE)
                THEN 'online'
            ELSE 'offline'
        END AS live_status
    FROM users
    ORDER BY created_at DESC, id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="overflow-x-hidden bg-orange-50">
    <?php include 'navbar.php'; ?>

    <main class="ml-60 mt-24 min-h-screen p-4">
        <div class="w-full bg-white h-fit p-4 rounded-2xl shadow-sm border border-orange-100 mb-4">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div>
                    <p class="font-bold text-2xl text-orange-500">USERS</p>
                    <p class="text-sm text-gray-500">Admin-only user management page.</p>
                </div>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <!-- CREATE USER -->
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5 mb-5">
            <div class="mb-4">
                <h2 class="text-xl font-bold text-orange-500">Create New User</h2>
                <p class="text-sm text-gray-500">Only admins can create users.</p>
            </div>

            <form method="POST" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Full Name</label>
                    <input type="text" name="full_name" class="w-full border rounded-xl px-4 py-2" required>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Username</label>
                    <input type="text" name="username" class="w-full border rounded-xl px-4 py-2" required>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Password</label>
                    <input type="password" name="password" class="w-full border rounded-xl px-4 py-2" required>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="role" class="w-full border rounded-xl px-4 py-2" required>
                        <option value="staff">Staff</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="md:col-span-2 xl:col-span-4">
                    <button type="submit" name="create_user" class="bg-orange-500 hover:bg-orange-600 text-white px-5 py-3 rounded-xl font-semibold">
                        Create User
                    </button>
                </div>
            </form>
        </div>

        <!-- USERS LIST -->
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-5">
            <div class="mb-4">
                <h2 class="text-xl font-bold text-orange-500">User List</h2>
                <p class="text-sm text-gray-500">Track accounts, roles, activity, and status.</p>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full border-collapse">
                    <thead>
                        <tr class="bg-orange-100 text-left">
                            <th class="p-3">ID</th>
                            <th class="p-3">Full Name</th>
                            <th class="p-3">Username</th>
                            <th class="p-3">Role</th>
                            <th class="p-3">Status</th>
                            <th class="p-3">Last Activity</th>
                            <th class="p-3">Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($users && $users->num_rows > 0): ?>
                            <?php while ($row = $users->fetch_assoc()): ?>
                                <tr class="border-b hover:bg-orange-50">
                                    <td class="p-3"><?= (int)$row['id'] ?></td>
                                    <td class="p-3 font-medium"><?= htmlspecialchars($row['full_name']) ?></td>
                                    <td class="p-3"><?= htmlspecialchars($row['username']) ?></td>
                                    <td class="p-3">
                                        <?php if ($row['role'] === 'admin'): ?>
                                            <span class="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-semibold">Admin</span>
                                        <?php else: ?>
                                            <span class="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-semibold">Staff</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <?php if ($row['live_status'] === 'online'): ?>
                                            <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">Online</span>
                                        <?php else: ?>
                                            <span class="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm font-semibold">Offline</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <?= !empty($row['last_activity']) ? date("M d, Y h:i A", strtotime($row['last_activity'])) : 'N/A' ?>
                                    </td>
                                    <td class="p-3">
                                        <?= !empty($row['created_at']) ? date("M d, Y h:i A", strtotime($row['created_at'])) : 'N/A' ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="p-6 text-center text-gray-500">No users found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>