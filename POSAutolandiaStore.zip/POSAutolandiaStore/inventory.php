<?php
include "db.php";

$message = "";
$success = false;

/*
IMPORTANT DATABASE CHANGES NEEDED

1) product_barcodes.barcode must NOT be UNIQUE anymore
Run this once in phpMyAdmin SQL:
ALTER TABLE product_barcodes DROP INDEX barcode;

2) barcode should allow NULL if you want no-barcode items
Run this once:
ALTER TABLE product_barcodes MODIFY barcode VARCHAR(100) NULL;

*/

/* QUICK RESTOCK */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["quick_restock"])) {
    $barcode = trim($_POST["barcode"] ?? "");
    $qty = max(1, (int)($_POST["qty"] ?? 1));

    if ($barcode === "") {
        $message = "Please scan or enter a barcode.";
    } else {
        $stmt = $conn->prepare("
            SELECT p.id, p.product_name
            FROM product_barcodes pb
            INNER JOIN products p ON pb.product_id = p.id
            WHERE pb.barcode = ?
            LIMIT 1
        ");
        $stmt->bind_param("s", $barcode);
        $stmt->execute();
        $found = $stmt->get_result()->fetch_assoc();

        if (!$found) {
            $message = "No product found for this barcode. Register the product first.";
        } else {
            $product_id = (int)$found["id"];
            $product_name = $found["product_name"];

            $conn->begin_transaction();

            try {
                $insert = $conn->prepare("
                    INSERT INTO product_barcodes (product_id, barcode, is_sold)
                    VALUES (?, ?, 0)
                ");

                for ($i = 0; $i < $qty; $i++) {
                    $insert->bind_param("is", $product_id, $barcode);
                    $insert->execute();
                }

                $update = $conn->prepare("
                    UPDATE products
                    SET stock_qty = stock_qty + ?
                    WHERE id = ?
                ");
                $update->bind_param("ii", $qty, $product_id);
                $update->execute();

                $conn->commit();
                $message = "{$product_name} restocked successfully. Added {$qty} item(s).";
                $success = true;
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Restock failed: " . $e->getMessage();
            }
        }
    }
}

/* LOAD INVENTORY */
$sql = "SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        ORDER BY p.product_name ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">

    <?php include "navbar.php"; ?>

    <div class="max-w-6xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex justify-between items-center mb-4">
            <h1 class="text-2xl font-bold text-orange-500">Inventory</h1>
            <div class="flex gap-2">
                <a href="inventory_add.php" class="bg-orange-400 text-white px-4 py-2 rounded-xl">+ Add Product</a>
                <a href="inventory_restock.php" class="bg-green-500 text-white px-4 py-2 rounded-xl">+ Restock Product</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <!-- QUICK RESTOCK BY BARCODE -->
        <div class="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-6">
            <h2 class="text-lg font-bold text-orange-500 mb-3">Quick Restock by Barcode</h2>
            <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                    type="text"
                    name="barcode"
                    placeholder="Scan same barcode here"
                    class="border rounded-xl px-4 py-2"
                    autofocus
                    required
                >
                <input
                    type="number"
                    name="qty"
                    value="1"
                    min="1"
                    class="border rounded-xl px-4 py-2"
                    required
                >
                <button
                    type="submit"
                    name="quick_restock"
                    class="bg-green-500 hover:bg-green-600 text-white rounded-xl px-4 py-2 font-semibold"
                >
                    Add Stock
                </button>
            </form>
            <p class="text-sm text-gray-500 mt-2">
                For bulk items like foods, scan the same barcode again to add more stock.
            </p>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-orange-100 text-left">
                        <th class="p-3">Image</th>
                        <th class="p-3">Product Name</th>
                        <th class="p-3">Category</th>
                        <th class="p-3">Price</th>
                        <th class="p-3">Stock</th>
                        <th class="p-3">Status</th>
                        <th class="p-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr class="border-b">
                            <td class="p-3">
                                <?php if (!empty($row['product_image']) && file_exists($row['product_image'])): ?>
                                    <img src="<?= htmlspecialchars($row['product_image']) ?>" alt="Product Image" class="w-16 h-16 object-cover rounded-lg border">
                                <?php else: ?>
                                    <div class="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center text-xs text-orange-400 font-bold">
                                        NO IMAGE
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 font-medium"><?= htmlspecialchars($row['product_name']) ?></td>
                            <td class="p-3"><?= htmlspecialchars($row['category_name'] ?? 'N/A') ?></td>
                            <td class="p-3">₱<?= number_format($row['price'], 2) ?></td>
                            <td class="p-3"><?= (int)$row['stock_qty'] ?></td>
                            <td class="p-3">
                                <?php if ((int)$row['stock_qty'] > 0): ?>
                                    <span class="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                                        In Stock
                                    </span>
                                <?php else: ?>
                                    <span class="bg-red-100 text-red-700 px-3 py-1 rounded-full text-sm font-semibold">
                                        Out of Stock
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3">
                                <div class="flex gap-2">
                                    <a href="inventory_restock.php?product_id=<?= (int)$row['id'] ?>" class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                                        Restock
                                    </a>
                                    <a href="inventory_edit.php?product_id=<?= (int)$row['id'] ?>" class="bg-orange-400 hover:bg-orange-500 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                                        Edit
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="p-6 text-center text-gray-500">No products found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>