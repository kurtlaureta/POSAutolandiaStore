<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="overflow-x-hidden">
    <?php
        include 'navbar.php';
    ?>
    <!-- main body content -->
    <nav class="ml-60 mt-24 min-h-screen flex-1 ">
        <div class="w-full bg-gray-300 h-fit p-4 rounded-2xl">
            <p class="font-bold ">INVENTORY</p>
        </div>
    </nav>
</body>
</html>