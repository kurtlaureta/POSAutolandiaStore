<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "point_of_sale_practice";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>