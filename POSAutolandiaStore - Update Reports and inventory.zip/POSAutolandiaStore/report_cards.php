<?php
include "db.php";

$mode = $_GET['mode'] ?? '';

if ($mode === 'date') {
    $date = $_GET['date'] ?? '';

    if ($date === '') {
        die("No date selected.");
    }

    $summaryStmt = $conn->prepare("
        SELECT 
            COUNT(*) AS total_transactions,
            COALESCE(SUM(total_amount), 0) AS total_sales
        FROM transactions
        WHERE DATE(created_at) = ?
    ");
    $summaryStmt->bind_param("s", $date);
    $summaryStmt->execute();
    $summary = $summaryStmt->get_result()->fetch_assoc();

    $itemsCountStmt = $conn->prepare("
        SELECT COALESCE(SUM(ti.qty), 0) AS total_items
        FROM transaction_items ti
        INNER JOIN transactions t ON ti.transaction_id = t.id
        WHERE DATE(t.created_at) = ?
    ");
    $itemsCountStmt->bind_param("s", $date);
    $itemsCountStmt->execute();
    $itemsCount = $itemsCountStmt->get_result()->fetch_assoc();

    $transactionsStmt = $conn->prepare("
        SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
        FROM transactions
        WHERE DATE(created_at) = ?
        ORDER BY created_at DESC
    ");
    $transactionsStmt->bind_param("s", $date);
    $transactionsStmt->execute();
    $transactions = $transactionsStmt->get_result();

    $itemsStmt = $conn->prepare("
        SELECT 
            ti.transaction_id,
            ti.product_name,
            ti.barcode,
            ti.price,
            ti.qty,
            ti.subtotal
        FROM transaction_items ti
        INNER JOIN transactions t ON ti.transaction_id = t.id
        WHERE DATE(t.created_at) = ?
        ORDER BY ti.transaction_id DESC, ti.id ASC
    ");
    $itemsStmt->bind_param("s", $date);
    $itemsStmt->execute();
    $itemsResult = $itemsStmt->get_result();

    $itemsByTransaction = [];
    while ($item = $itemsResult->fetch_assoc()) {
        $txId = $item['transaction_id'];
        if (!isset($itemsByTransaction[$txId])) {
            $itemsByTransaction[$txId] = [];
        }
        $itemsByTransaction[$txId][] = $item;
    }
}
elseif ($mode === 'transaction') {
    $id = (int)($_GET['id'] ?? 0);

    if ($id <= 0) {
        die("Invalid transaction ID.");
    }

    $txStmt = $conn->prepare("
        SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
        FROM transactions
        WHERE id = ?
        LIMIT 1
    ");
    $txStmt->bind_param("i", $id);
    $txStmt->execute();
    $transaction = $txStmt->get_result()->fetch_assoc();

    if (!$transaction) {
        die("Transaction not found.");
    }

    $itemsStmt = $conn->prepare("
        SELECT product_name, barcode, price, qty, subtotal
        FROM transaction_items
        WHERE transaction_id = ?
        ORDER BY id ASC
    ");
    $itemsStmt->bind_param("i", $id);
    $itemsStmt->execute();
    $transactionItems = $itemsStmt->get_result();

    $transactionItemCountStmt = $conn->prepare("
        SELECT COALESCE(SUM(qty), 0) AS total_items
        FROM transaction_items
        WHERE transaction_id = ?
    ");
    $transactionItemCountStmt->bind_param("i", $id);
    $transactionItemCountStmt->execute();
    $transactionItemCount = $transactionItemCountStmt->get_result()->fetch_assoc();
}
else {
    die("Invalid mode.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Cards</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 min-h-screen p-6">

<?php include "navbar.php"; ?>

<div class="max-w-7xl mx-auto mt-24">

    <?php if ($mode === 'date'): ?>
        <div class="bg-white rounded-3xl shadow-sm border border-orange-100 p-6 mb-6">
            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                    <p class="text-sm font-semibold uppercase tracking-wide text-orange-500">Daily Report</p>
                    <h1 class="text-3xl font-bold text-gray-900 mt-1">Sales for <?= htmlspecialchars($date) ?></h1>
                    <p class="text-gray-500 mt-1">Clean summary of all transactions and sold items for the selected date.</p>
                </div>
                <a href="reports.php"
                   class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2.5 rounded-xl font-semibold text-center">
                    Back to Reports
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Report Date</p>
                <h2 class="text-2xl font-bold text-gray-900 mt-1"><?= htmlspecialchars($date) ?></h2>
            </div>
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Total Transactions</p>
                <h2 class="text-2xl font-bold text-blue-600 mt-1"><?= (int)($summary['total_transactions'] ?? 0) ?></h2>
            </div>
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Total Sales</p>
                <h2 class="text-2xl font-bold text-orange-600 mt-1">₱<?= number_format((float)($summary['total_sales'] ?? 0), 2) ?></h2>
                <p class="text-sm text-gray-500 mt-1"><?= (int)($itemsCount['total_items'] ?? 0) ?> item(s) sold</p>
            </div>
        </div>

        <div class="space-y-6">
            <?php if ($transactions && $transactions->num_rows > 0): ?>
                <?php while ($tx = $transactions->fetch_assoc()): ?>
                    <?php
                        $txItems = $itemsByTransaction[$tx['id']] ?? [];
                        $txItemCount = 0;
                        foreach ($txItems as $txItem) {
                            $txItemCount += (int)$txItem['qty'];
                        }
                    ?>
                    <div class="bg-white rounded-3xl shadow-sm border border-orange-100 overflow-hidden">
                        <div class="px-6 py-5 border-b border-orange-100 bg-orange-50">
                            <div class="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
                                <div>
                                    <p class="text-xs font-semibold uppercase tracking-wide text-orange-500">Transaction</p>
                                    <h3 class="text-2xl font-bold text-gray-900 mt-1">#<?= (int)$tx['id'] ?></h3>
                                    <div class="mt-2 space-y-1 text-sm text-gray-600">
                                        <p><span class="font-semibold text-gray-800">Receipt No:</span> <?= htmlspecialchars($tx['receipt_no']) ?></p>
                                        <p><span class="font-semibold text-gray-800">Date & Time:</span> <?= htmlspecialchars($tx['created_at']) ?></p>
                                    </div>
                                </div>

                                <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                                    <div class="bg-white rounded-2xl px-4 py-3 border border-orange-100">
                                        <p class="text-xs text-gray-500">Cash</p>
                                        <p class="font-bold text-gray-800">₱<?= number_format((float)$tx['cash_amount'], 2) ?></p>
                                    </div>
                                    <div class="bg-white rounded-2xl px-4 py-3 border border-orange-100">
                                        <p class="text-xs text-gray-500">Change</p>
                                        <p class="font-bold text-gray-800">₱<?= number_format((float)$tx['change_amount'], 2) ?></p>
                                    </div>
                                    <div class="bg-white rounded-2xl px-4 py-3 border border-orange-100">
                                        <p class="text-xs text-gray-500">Items</p>
                                        <p class="font-bold text-gray-800"><?= $txItemCount ?></p>
                                    </div>
                                    <div class="bg-white rounded-2xl px-4 py-3 border border-orange-100">
                                        <p class="text-xs text-gray-500">Total</p>
                                        <p class="font-bold text-orange-600">₱<?= number_format((float)$tx['total_amount'], 2) ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="p-6">
                            <?php if (!empty($txItems)): ?>
                                <div class="overflow-x-auto">
                                    <table class="w-full text-sm">
                                        <thead>
                                            <tr class="bg-orange-50 text-gray-700">
                                                <th class="text-left px-4 py-3 rounded-l-xl">Product</th>
                                                <th class="text-left px-4 py-3">Barcode</th>
                                                <th class="text-right px-4 py-3">Price</th>
                                                <th class="text-right px-4 py-3">Qty</th>
                                                <th class="text-right px-4 py-3 rounded-r-xl">Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($txItems as $item): ?>
                                                <tr class="border-b border-orange-50 last:border-b-0">
                                                    <td class="px-4 py-3 font-medium text-gray-900"><?= htmlspecialchars($item['product_name']) ?></td>
                                                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($item['barcode'] ?: 'No Barcode') ?></td>
                                                    <td class="px-4 py-3 text-right">₱<?= number_format((float)$item['price'], 2) ?></td>
                                                    <td class="px-4 py-3 text-right"><?= (int)$item['qty'] ?></td>
                                                    <td class="px-4 py-3 text-right font-semibold text-orange-600">₱<?= number_format((float)$item['subtotal'], 2) ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center text-gray-500 py-8">No item records found for this transaction.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="bg-white rounded-3xl shadow-sm border border-orange-100 p-8 text-center text-gray-500">
                    No transactions found for this date.
                </div>
            <?php endif; ?>
        </div>

    <?php elseif ($mode === 'transaction'): ?>
        <div class="bg-white rounded-3xl shadow-sm border border-orange-100 p-6 mb-6">
            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                    <p class="text-sm font-semibold uppercase tracking-wide text-orange-500">Transaction Report</p>
                    <h1 class="text-3xl font-bold text-gray-900 mt-1">Transaction #<?= (int)$transaction['id'] ?></h1>
                    <p class="text-gray-500 mt-1">Simplified receipt-style transaction breakdown.</p>
                </div>
                <a href="reports.php"
                   class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2.5 rounded-xl font-semibold text-center">
                    Back to Reports
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Receipt No</p>
                <h2 class="text-xl font-bold text-gray-900 mt-1"><?= htmlspecialchars($transaction['receipt_no']) ?></h2>
            </div>
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Cash</p>
                <h2 class="text-xl font-bold text-gray-900 mt-1">₱<?= number_format((float)$transaction['cash_amount'], 2) ?></h2>
            </div>
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Change</p>
                <h2 class="text-xl font-bold text-gray-900 mt-1">₱<?= number_format((float)$transaction['change_amount'], 2) ?></h2>
            </div>
            <div class="bg-white border border-orange-100 rounded-2xl p-5 shadow-sm">
                <p class="text-sm text-gray-500">Grand Total</p>
                <h2 class="text-2xl font-bold text-orange-600 mt-1">₱<?= number_format((float)$transaction['total_amount'], 2) ?></h2>
            </div>
        </div>

        <div class="bg-white rounded-3xl shadow-sm border border-orange-100 overflow-hidden mb-6">
            <div class="px-6 py-5 border-b border-orange-100 bg-orange-50">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                        <p class="text-xs font-semibold uppercase tracking-wide text-orange-500">Transaction Details</p>
                        <h3 class="text-xl font-bold text-gray-900 mt-1">Purchased Items</h3>
                        <p class="text-sm text-gray-600 mt-1">Date & Time: <?= htmlspecialchars($transaction['created_at']) ?></p>
                    </div>
                    <div class="bg-white border border-orange-100 rounded-2xl px-4 py-3">
                        <p class="text-xs text-gray-500">Total Items</p>
                        <p class="font-bold text-gray-900"><?= (int)($transactionItemCount['total_items'] ?? 0) ?></p>
                    </div>
                </div>
            </div>

            <div class="p-6">
                <?php if ($transactionItems && $transactionItems->num_rows > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="bg-orange-50 text-gray-700">
                                    <th class="text-left px-4 py-3 rounded-l-xl">Product</th>
                                    <th class="text-left px-4 py-3">Barcode</th>
                                    <th class="text-right px-4 py-3">Price</th>
                                    <th class="text-right px-4 py-3">Qty</th>
                                    <th class="text-right px-4 py-3 rounded-r-xl">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = $transactionItems->fetch_assoc()): ?>
                                    <tr class="border-b border-orange-50 last:border-b-0">
                                        <td class="px-4 py-3 font-medium text-gray-900"><?= htmlspecialchars($item['product_name']) ?></td>
                                        <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($item['barcode'] ?: 'No Barcode') ?></td>
                                        <td class="px-4 py-3 text-right">₱<?= number_format((float)$item['price'], 2) ?></td>
                                        <td class="px-4 py-3 text-right"><?= (int)$item['qty'] ?></td>
                                        <td class="px-4 py-3 text-right font-semibold text-orange-600">₱<?= number_format((float)$item['subtotal'], 2) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center text-gray-500 py-8">No items found for this transaction.</div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

</div>

</body>
</html>