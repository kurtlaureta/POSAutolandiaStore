<?php
session_start();
include "db.php";

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$message = "";

/* ADD TO CART BY BARCODE */
if (isset($_POST['scan_barcode'])) {
    $barcode = trim($_POST['barcode'] ?? "");

    if ($barcode !== "") {
        $stmt = $conn->prepare("SELECT * FROM products WHERE barcode = ? LIMIT 1");
        $stmt->bind_param("s", $barcode);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        if ($product) {
            if ($product['stock_qty'] <= 0) {
                $message = "Product is out of stock.";
            } else {
                $productId = $product['id'];

                if (isset($_SESSION['cart'][$productId])) {
                    if ($_SESSION['cart'][$productId]['qty'] < $product['stock_qty']) {
                        $_SESSION['cart'][$productId]['qty']++;
                    } else {
                        $message = "Not enough stock available.";
                    }
                } else {
                    $_SESSION['cart'][$productId] = [
                        'product_id' => $product['id'],
                        'barcode' => $product['barcode'],
                        'product_name' => $product['product_name'],
                        'price' => $product['price'],
                        'qty' => 1,
                        'stock_qty' => $product['stock_qty']
                    ];
                }
            }
        } else {
            $message = "Barcode not found.";
        }
    }
}

/* UPDATE QTY */
if (isset($_POST['update_qty'])) {
    $productId = (int)$_POST['product_id'];
    $qty = (int)$_POST['qty'];

    if (isset($_SESSION['cart'][$productId])) {
        if ($qty <= 0) {
            unset($_SESSION['cart'][$productId]);
        } else {
            if ($qty <= $_SESSION['cart'][$productId]['stock_qty']) {
                $_SESSION['cart'][$productId]['qty'] = $qty;
            } else {
                $message = "Quantity exceeds stock.";
            }
        }
    }
}

/* REMOVE ITEM */
if (isset($_POST['remove_item'])) {
    $productId = (int)$_POST['product_id'];
    unset($_SESSION['cart'][$productId]);
}

/* CHECKOUT */
if (isset($_POST['checkout'])) {
    $cash = (float)($_POST['cash_amount'] ?? 0);

    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['qty'];
    }

    if ($total <= 0) {
        $message = "Cart is empty.";
    } elseif ($cash < $total) {
        $message = "Insufficient cash.";
    } else {
        $receiptNo = "RCPT-" . date("YmdHis");
        $change = $cash - $total;

        $conn->begin_transaction();

        try {
            $stmt = $conn->prepare("INSERT INTO sales (receipt_no, total_amount, cash_amount, change_amount) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sddd", $receiptNo, $total, $cash, $change);
            $stmt->execute();
            $saleId = $conn->insert_id;

            foreach ($_SESSION['cart'] as $item) {
                $subtotal = $item['price'] * $item['qty'];

                $stmtItem = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, barcode, product_name, price, qty, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmtItem->bind_param(
                    "iissdid",
                    $saleId,
                    $item['product_id'],
                    $item['barcode'],
                    $item['product_name'],
                    $item['price'],
                    $item['qty'],
                    $subtotal
                );
                $stmtItem->execute();

                $stmtStock = $conn->prepare("UPDATE products SET stock_qty = stock_qty - ? WHERE id = ? AND stock_qty >= ?");
                $stmtStock->bind_param("iii", $item['qty'], $item['product_id'], $item['qty']);
                $stmtStock->execute();
            }

            $conn->commit();
            $_SESSION['cart'] = [];
            $message = "Checkout successful. Receipt No: " . $receiptNo;
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Checkout failed.";
        }
    }
}

$total = 0;
foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['qty'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <style>
        /* Hide caret on everything by default */
        * {
            caret-color: transparent;
        }

        /* Allow caret only on real text inputs */
        input[type="text"],
        input[type="search"],
        input[type="password"],
        input[type="email"],
        input[type="number"],
        textarea,
        [contenteditable="true"] {
            caret-color: auto;
        }
    </style>
</head>
<body class="bg-orange-50 p-6">
    <div class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="lg:col-span-2 bg-white rounded-2xl shadow p-6">
            <h1 class="text-2xl font-bold text-orange-500 mb-4">Point of Sale</h1>

            <?php if ($message): ?>
                <div class="mb-4 p-3 rounded-xl bg-orange-100 text-orange-700">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="mb-6">
                <label class="block font-medium mb-2">Scan Barcode</label>
                <div class="flex gap-2">
                    <input type="text" name="barcode" class="w-full border rounded-xl px-4 py-3" placeholder="Scan barcode here" autofocus>
                    <button type="submit" name="scan_barcode" class="bg-orange-400 text-white px-6 rounded-xl">Add</button>
                </div>
            </form>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-orange-100 text-left">
                            <th class="p-3">Barcode</th>
                            <th class="p-3">Product</th>
                            <th class="p-3">Price</th>
                            <th class="p-3">Qty</th>
                            <th class="p-3">Subtotal</th>
                            <th class="p-3">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($_SESSION['cart'])): ?>
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                                <tr class="border-b">
                                    <td class="p-3"><?= htmlspecialchars($item['barcode']) ?></td>
                                    <td class="p-3"><?= htmlspecialchars($item['product_name']) ?></td>
                                    <td class="p-3">₱<?= number_format($item['price'], 2) ?></td>
                                    <td class="p-3">
                                        <form method="POST" class="flex gap-2 items-center">
                                            <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                            <input type="number" name="qty" value="<?= $item['qty'] ?>" min="1" class="w-20 border rounded-lg px-2 py-1">
                                            <button type="submit" name="update_qty" class="bg-blue-500 text-white px-3 py-1 rounded-lg">Update</button>
                                        </form>
                                    </td>
                                    <td class="p-3">₱<?= number_format($item['price'] * $item['qty'], 2) ?></td>
                                    <td class="p-3">
                                        <form method="POST">
                                            <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                            <button type="submit" name="remove_item" class="bg-red-500 text-white px-3 py-1 rounded-lg">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="p-4 text-center text-gray-500">Cart is empty.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow p-6 h-fit">
            <h2 class="text-xl font-bold text-orange-500 mb-4">Checkout</h2>

            <div class="space-y-3">
                <div class="flex justify-between text-lg">
                    <span>Total:</span>
                    <span class="font-bold">₱<?= number_format($total, 2) ?></span>
                </div>

                <form method="POST" class="space-y-3">
                    <div>
                        <label class="block font-medium mb-1">Cash Amount</label>
                        <input type="number" step="0.01" name="cash_amount" class="w-full border rounded-xl px-4 py-2" required>
                    </div>

                    <button type="submit" name="checkout" class="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl font-bold">
                        Checkout
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>