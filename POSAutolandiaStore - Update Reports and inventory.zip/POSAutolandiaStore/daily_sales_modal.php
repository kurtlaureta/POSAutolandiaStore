<?php
include "db.php";

$date = $_GET['date'] ?? '';

if ($date === '') {
    echo '<div class="text-red-600">No date selected.</div>';
    exit;
}

$summaryStmt = $conn->prepare("
    SELECT 
        COUNT(*) AS total_transactions,
        COALESCE(SUM(total_amount), 0) AS total_sales
    FROM transactions
    WHERE DATE(created_at) = ?
");
$summaryStmt->bind_param("s", $date);
$summaryStmt->execute();
$summary = $summaryStmt->get_result()->fetch_assoc();

$itemCountStmt = $conn->prepare("
    SELECT COALESCE(SUM(ti.qty), 0) AS total_items
    FROM transaction_items ti
    INNER JOIN transactions t ON ti.transaction_id = t.id
    WHERE DATE(t.created_at) = ?
");
$itemCountStmt->bind_param("s", $date);
$itemCountStmt->execute();
$itemCount = $itemCountStmt->get_result()->fetch_assoc();

$transactionsStmt = $conn->prepare("
    SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
    FROM transactions
    WHERE DATE(created_at) = ?
    ORDER BY created_at DESC
");
$transactionsStmt->bind_param("s", $date);
$transactionsStmt->execute();
$transactions = $transactionsStmt->get_result();

$itemsStmt = $conn->prepare("
    SELECT 
        ti.transaction_id,
        ti.product_name,
        ti.barcode,
        ti.price,
        ti.qty,
        ti.subtotal
    FROM transaction_items ti
    INNER JOIN transactions t ON ti.transaction_id = t.id
    WHERE DATE(t.created_at) = ?
    ORDER BY ti.transaction_id DESC, ti.id ASC
");
$itemsStmt->bind_param("s", $date);
$itemsStmt->execute();
$itemsResult = $itemsStmt->get_result();

$itemsByTransaction = [];
while ($item = $itemsResult->fetch_assoc()) {
    $txId = $item['transaction_id'];
    if (!isset($itemsByTransaction[$txId])) {
        $itemsByTransaction[$txId] = [];
    }
    $itemsByTransaction[$txId][] = $item;
}
?>

<div class="mb-4">
    <h2 class="text-2xl font-bold text-orange-500">Daily Sales Details</h2>
    <p class="text-sm text-gray-500">Report for <?= htmlspecialchars($date) ?></p>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
    <div class="bg-orange-50 border border-orange-100 rounded-2xl p-4">
        <p class="text-xs uppercase text-gray-500">Date</p>
        <p class="text-xl font-bold text-gray-800 mt-1"><?= htmlspecialchars($date) ?></p>
    </div>
    <div class="bg-orange-50 border border-orange-100 rounded-2xl p-4">
        <p class="text-xs uppercase text-gray-500">Transactions</p>
        <p class="text-xl font-bold text-gray-800 mt-1"><?= (int)($summary['total_transactions'] ?? 0) ?></p>
    </div>
    <div class="bg-orange-50 border border-orange-100 rounded-2xl p-4">
        <p class="text-xs uppercase text-gray-500">Sales / Items</p>
        <p class="text-xl font-bold text-orange-600 mt-1">₱<?= number_format((float)($summary['total_sales'] ?? 0), 2) ?></p>
        <p class="text-sm text-gray-500 mt-1"><?= (int)($itemCount['total_items'] ?? 0) ?> item(s)</p>
    </div>
</div>

<div class="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
    <?php if ($transactions && $transactions->num_rows > 0): ?>
        <?php while ($tx = $transactions->fetch_assoc()): ?>
            <div class="border border-orange-100 rounded-2xl overflow-hidden bg-white">
                <div class="bg-orange-50 px-4 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                    <div>
                        <p class="font-bold text-gray-800">Transaction #<?= (int)$tx['id'] ?></p>
                        <p class="text-sm text-gray-600">Receipt: <?= htmlspecialchars($tx['receipt_no']) ?></p>
                        <p class="text-sm text-gray-600"><?= htmlspecialchars($tx['created_at']) ?></p>
                    </div>
                    <div class="text-left md:text-right">
                        <p class="text-sm text-gray-600">Cash: ₱<?= number_format((float)$tx['cash_amount'], 2) ?></p>
                        <p class="text-sm text-gray-600">Change: ₱<?= number_format((float)$tx['change_amount'], 2) ?></p>
                        <p class="text-lg font-bold text-orange-600">₱<?= number_format((float)$tx['total_amount'], 2) ?></p>
                    </div>
                </div>

                <div class="p-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                        <?php if (!empty($itemsByTransaction[$tx['id']])): ?>
                            <?php foreach ($itemsByTransaction[$tx['id']] as $item): ?>
                                <div class="border rounded-xl p-3 bg-orange-50/50">
                                    <p class="font-semibold text-gray-800"><?= htmlspecialchars($item['product_name']) ?></p>
                                    <p class="text-sm text-gray-500">Barcode: <?= htmlspecialchars($item['barcode'] ?? '') ?></p>
                                    <p class="text-sm text-gray-500">Price: ₱<?= number_format((float)$item['price'], 2) ?></p>
                                    <p class="text-sm text-gray-500">Qty: <?= (int)$item['qty'] ?></p>
                                    <p class="font-bold text-orange-600 mt-2">Subtotal: ₱<?= number_format((float)$item['subtotal'], 2) ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-sm text-gray-500">No item records found.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="text-center text-gray-500 py-8">No transactions found for this date.</div>
    <?php endif; ?>
</div>