<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Iosevka+Charon:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style type="text/tailwindcss">
        @reference "tailwindcss";
        @theme{
            --font-roboto: "ROBOTO", "sans-serif";
        }
        h1{
            @apply font-bold text-[1.3rem];
        }
        h2{
            @apply font-bold text-[1rem];
        }
        body{
            @apply font-roboto;
        }
    </style>
</head>
<body>
    <!-- top navbar -->
    <nav class="min-w-screen">
        <div class="w-screen bg-orange-50 p-4 shadow-sm flex flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-4 max-sm:flex-col">
                <h1>Autolandia STORE</h1>
                <div class="relative border border-gray-200 shadow-sm px-8 py-2 rounded-[0.55rem] bg-white hover:border-orange-300">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-5 absolute left-1 top-1/3 -translate-y-1 ml-1">
                        <path fill-rule="evenodd" d="M10.5 3.75a6.75 6.75 0 1 0 0 13.5 6.75 6.75 0 0 0 0-13.5ZM2.25 10.5a8.25 8.25 0 1 1 14.59 5.28l4.69 4.69a.75.75 0 1 1-1.06 1.06l-4.69-4.69A8.25 8.25 0 0 1 2.25 10.5Z" clip-rule="evenodd" />
                    </svg>
                    <input type="text" placeholder="Search for products..." class="outline-0 font-medium w-90">
                </div>
            </div>
            <div class="flex flex-row items-center gap-4">
                <h2>3/17/2026 - 6:27PM</h2>
                <button class="bg-orange-400 border-orange-400 text-white border-2 px-4 py-2 rounded-2xl flex items-center gap-2 hover:bg-white hover:text-orange-400 cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-4">
                        <path fill-rule="evenodd" d="M15 3.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 .75.75v4.5a.75.75 0 0 1-1.5 0V5.56l-3.97 3.97a.75.75 0 1 1-1.06-1.06l3.97-3.97h-2.69a.75.75 0 0 1-.75-.75Zm-12 0A.75.75 0 0 1 3.75 3h4.5a.75.75 0 0 1 0 1.5H5.56l3.97 3.97a.75.75 0 0 1-1.06 1.06L4.5 5.56v2.69a.75.75 0 0 1-1.5 0v-4.5Zm11.47 11.78a.75.75 0 1 1 1.06-1.06l3.97 3.97v-2.69a.75.75 0 0 1 1.5 0v4.5a.75.75 0 0 1-.75.75h-4.5a.75.75 0 0 1 0-1.5h2.69l-3.97-3.97Zm-4.94-1.06a.75.75 0 0 1 0 1.06L5.56 19.5h2.69a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75v-4.5a.75.75 0 0 1 1.5 0v2.69l3.97-3.97a.75.75 0 0 1 1.06 0Z" clip-rule="evenodd" />
                    </svg>
                    <p class="font-medium">FOOD</p>
                </button>
            </div>
        </div>
    </nav>
</body>
</html>