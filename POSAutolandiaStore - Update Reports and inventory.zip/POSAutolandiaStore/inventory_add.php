<?php
include "db.php";

$message = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $product_name = trim($_POST["product_name"] ?? "");
    $category_id = isset($_POST["category_id"]) && $_POST["category_id"] !== "" ? (int)$_POST["category_id"] : null;
    $price = (float)($_POST["price"] ?? 0);
    $barcode_list_raw = trim($_POST["barcode_list"] ?? "");
    $no_barcode_qty = max(0, (int)($_POST["no_barcode_qty"] ?? 0));
    $product_image = null;

    if ($product_name === "" || $price <= 0) {
        $message = "Please fill in product name and price correctly.";
    } else {
        $barcodes = preg_split('/\r\n|\r|\n/', $barcode_list_raw);
        $barcodes = array_map('trim', $barcodes);
        $barcodes = array_values(array_filter($barcodes, fn($v) => $v !== ""));
        $barcodes = array_values(array_unique($barcodes));

        if (count($barcodes) === 0 && $no_barcode_qty <= 0) {
            $message = "Please scan at least one barcode or enter initial quantity for no-barcode products.";
        }

        if (isset($_FILES["product_image"]) && $_FILES["product_image"]["error"] === 0) {
            $uploadDir = "uploads/";

            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $fileTmpPath = $_FILES["product_image"]["tmp_name"];
            $fileName = $_FILES["product_image"]["name"];
            $fileSize = $_FILES["product_image"]["size"];
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            $allowedExt = ["jpg", "jpeg", "png", "gif", "webp"];

            if (!in_array($fileExt, $allowedExt)) {
                $message = "Invalid image file type.";
            } elseif ($fileSize > 5 * 1024 * 1024) {
                $message = "Image file is too large. Maximum size is 5MB.";
            } else {
                $newFileName = "product_" . time() . "_" . uniqid() . "." . $fileExt;
                $destPath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    $product_image = $destPath;
                } else {
                    $message = "Failed to upload image.";
                }
            }
        }

        if ($message === "") {
            $conn->begin_transaction();

            try {
                /*
                    RULES:
                    1. If barcode already exists anywhere in product_barcodes:
                       - do NOT insert another barcode row
                       - just increase stock of the linked product
                    2. If barcode does not exist:
                       - attach it to an existing matching product (same name + price) if found
                       - otherwise create a new product, then insert the barcode
                    3. For no-barcode products:
                       - use existing same name + price product if found
                       - otherwise create a new product
                       - increase stock only
                */

                $matched_product_id = null;
                $matched_product_name = null;
                $existing_product_image = null;

                // First, try finding product by existing scanned barcode
                if (count($barcodes) > 0) {
                    $findByBarcode = $conn->prepare("
                        SELECT p.id, p.product_name, p.product_image
                        FROM product_barcodes pb
                        INNER JOIN products p ON pb.product_id = p.id
                        WHERE pb.barcode = ?
                        LIMIT 1
                    ");

                    foreach ($barcodes as $barcode) {
                        $findByBarcode->bind_param("s", $barcode);
                        $findByBarcode->execute();
                        $barcodeResult = $findByBarcode->get_result();
                        $barcodeProduct = $barcodeResult->fetch_assoc();

                        if ($barcodeProduct) {
                            $matched_product_id = (int)$barcodeProduct["id"];
                            $matched_product_name = $barcodeProduct["product_name"];
                            $existing_product_image = $barcodeProduct["product_image"];
                            break;
                        }
                    }
                }

                // If no product found by barcode, try finding same product by name + price
                if ($matched_product_id === null) {
                    $findProduct = $conn->prepare("
                        SELECT id, product_image
                        FROM products
                        WHERE product_name = ? AND price = ?
                        LIMIT 1
                    ");
                    $findProduct->bind_param("sd", $product_name, $price);
                    $findProduct->execute();
                    $productResult = $findProduct->get_result();
                    $existingProduct = $productResult->fetch_assoc();

                    if ($existingProduct) {
                        $matched_product_id = (int)$existingProduct["id"];
                        $matched_product_name = $product_name;
                        $existing_product_image = $existingProduct["product_image"];
                    }
                }

                // If still no product, create one
                if ($matched_product_id === null) {
                    $insertProduct = $conn->prepare("
                        INSERT INTO products (product_name, product_image, category_id, price, stock_qty)
                        VALUES (?, ?, ?, ?, 0)
                    ");
                    $insertProduct->bind_param("ssid", $product_name, $product_image, $category_id, $price);
                    $insertProduct->execute();

                    $matched_product_id = $conn->insert_id;
                    $matched_product_name = $product_name;
                } else {
                    // Update matched product basic info
                    if ($product_image === null) {
                        $product_image = $existing_product_image;
                    }

                    $updateProduct = $conn->prepare("
                        UPDATE products
                        SET category_id = ?, product_image = ?, product_name = ?, price = ?
                        WHERE id = ?
                    ");
                    $updateProduct->bind_param("issdi", $category_id, $product_image, $product_name, $price, $matched_product_id);
                    $updateProduct->execute();
                }

                $newBarcodeCount = 0;
                $existingBarcodeCount = 0;
                $existingBarcodeList = [];
                $conflictBarcodeList = [];

                if (count($barcodes) > 0) {
                    $checkBarcode = $conn->prepare("
                        SELECT product_id
                        FROM product_barcodes
                        WHERE barcode = ?
                        LIMIT 1
                    ");

                    $insertBarcode = $conn->prepare("
                        INSERT INTO product_barcodes (product_id, barcode, is_sold)
                        VALUES (?, ?, 0)
                    ");

                    foreach ($barcodes as $barcode) {
                        $checkBarcode->bind_param("s", $barcode);
                        $checkBarcode->execute();
                        $barcodeCheckResult = $checkBarcode->get_result();
                        $existingBarcode = $barcodeCheckResult->fetch_assoc();

                        if ($existingBarcode) {
                            $existingBarcodeProductId = (int)$existingBarcode["product_id"];

                            if ($existingBarcodeProductId === (int)$matched_product_id) {
                                // Same barcode already belongs to the same product
                                $existingBarcodeCount++;
                                $existingBarcodeList[] = $barcode;
                            } else {
                                // Barcode belongs to another product, do not attach it here
                                $conflictBarcodeList[] = $barcode;
                            }

                            continue;
                        }

                        $insertBarcode->bind_param("is", $matched_product_id, $barcode);
                        $insertBarcode->execute();
                        $newBarcodeCount++;
                    }
                }

                /*
                    STOCK LOGIC:
                    - Every scanned barcode counts as stock for the matched product,
                      even if barcode already existed for the same product.
                    - But barcodes that belong to another product are skipped and do not add stock.
                    - No-barcode product uses no_barcode_qty.
                */
                if (count($barcodes) > 0) {
                    $stockToAdd = count($barcodes) - count($conflictBarcodeList);
                } else {
                    $stockToAdd = $no_barcode_qty;
                }

                if ($stockToAdd > 0) {
                    $updateStock = $conn->prepare("
                        UPDATE products
                        SET stock_qty = stock_qty + ?
                        WHERE id = ?
                    ");
                    $updateStock->bind_param("ii", $stockToAdd, $matched_product_id);
                    $updateStock->execute();
                }

                $conn->commit();
                $success = true;

                if (count($barcodes) === 0) {
                    $message = "Product saved successfully. Initial stock added: {$no_barcode_qty}.";
                } else {
                    $parts = [];

                    if ($newBarcodeCount > 0) {
                        $parts[] = "New barcode(s) registered: {$newBarcodeCount}";
                    }

                    if ($existingBarcodeCount > 0) {
                        $parts[] = "Existing barcode(s) found for the same product and stock increased only: {$existingBarcodeCount}";
                    }

                    if (count($conflictBarcodeList) > 0) {
                        $parts[] = "Barcode(s) skipped because they belong to another product: " . implode(", ", $conflictBarcodeList);
                    }

                    $parts[] = "Stock added: {$stockToAdd}";
                    $parts[] = "Product: {$matched_product_name}";

                    $message = implode(". ", $parts) . ".";
                }

            } catch (Exception $e) {
                $conn->rollback();
                $message = "Error saving inventory: " . $e->getMessage();
            }
        }
    }
}

$categories = $conn->query("SELECT * FROM categories ORDER BY category_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Inventory</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-4xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h1 class="text-2xl font-bold text-orange-500">Add Inventory by Barcode Batch</h1>
                <p class="text-gray-500">Type product once, scan many barcodes, and stock updates automatically.</p>
            </div>
            <a href="inventory.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                Back
            </a>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="space-y-5">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block font-medium mb-1">Product Name</label>
                    <input type="text" name="product_name" class="w-full border rounded-xl px-4 py-2" required>
                </div>

                <div>
                    <label class="block font-medium mb-1">Category</label>
                    <select name="category_id" class="w-full border rounded-xl px-4 py-2">
                        <option value="">Select Category</option>
                        <?php while ($cat = $categories->fetch_assoc()): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['category_name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div>
                    <label class="block font-medium mb-1">Price</label>
                    <input type="number" step="0.01" name="price" class="w-full border rounded-xl px-4 py-2" required>
                </div>

                <div>
                    <label class="block font-medium mb-1">Product Image</label>
                    <input type="file" name="product_image" accept="image/*" class="w-full border rounded-xl px-4 py-2 bg-white">
                </div>
            </div>

            <div>
                <label class="block font-medium mb-1">Initial Quantity (for no-barcode products)</label>
                <input type="number" name="no_barcode_qty" min="0" value="0" class="w-full border rounded-xl px-4 py-2">
            </div>

            <div class="bg-orange-50 border border-orange-200 rounded-2xl p-4">
                <label class="block font-medium mb-2">Scan Barcode</label>
                <input 
                    type="text" 
                    id="barcode_input" 
                    class="w-full border rounded-xl px-4 py-3 mb-3" 
                    placeholder="Scan barcode here and press Enter (optional)"
                    autocomplete="off"
                >

                <label class="block font-medium mb-2">Registered Barcodes for This Product</label>
                <textarea
                    name="barcode_list"
                    id="barcode_list"
                    rows="10"
                    class="w-full border rounded-xl px-4 py-3"
                    placeholder="Optional: scanned barcodes will appear here, one per line"
                ></textarea>

                <div class="mt-3 flex flex-wrap gap-2">
                    <button type="button" id="clearBarcodes" class="bg-red-400 hover:bg-red-500 text-white px-4 py-2 rounded-xl font-semibold cursor-pointer">
                        Clear Barcodes
                    </button>
                    <span id="barcodeCount" class="bg-orange-100 text-orange-700 px-4 py-2 rounded-xl font-semibold">
                        Total Barcodes: 0
                    </span>
                </div>

                <p class="text-sm text-gray-500 mt-3">
                    Barcode is optional. If the same barcode already exists for the same product, stock will increase only and no duplicate barcode row will be added.
                </p>
            </div>

            <div class="flex justify-between">
                <button type="submit" class="bg-orange-400 hover:bg-orange-500 text-white px-6 py-2 rounded-xl font-semibold cursor-pointer">
                    Save Inventory Batch
                </button>
                <a href="inventory.php" class="block px-6 py-2 text-white bg-red-400 hover:bg-red-500 rounded-2xl text-center">
                    Cancel
                </a>
            </div>
        </form>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const barcodeInput = document.getElementById('barcode_input');
        const barcodeList = document.getElementById('barcode_list');
        const barcodeCount = document.getElementById('barcodeCount');
        const clearBarcodes = document.getElementById('clearBarcodes');

        function updateCount() {
            const lines = barcodeList.value
                .split(/\r\n|\r|\n/)
                .map(v => v.trim())
                .filter(v => v !== '');
            barcodeCount.textContent = 'Total Barcodes: ' + lines.length;
        }

        function barcodeExists(value) {
            const lines = barcodeList.value
                .split(/\r\n|\r|\n/)
                .map(v => v.trim());
            return lines.includes(value);
        }

        if (barcodeInput) {
            barcodeInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();

                    const value = barcodeInput.value.trim();
                    if (value === '') return;

                    if (!barcodeExists(value)) {
                        if (barcodeList.value.trim() === '') {
                            barcodeList.value = value;
                        } else {
                            barcodeList.value += '\n' + value;
                        }
                    }

                    barcodeInput.value = '';
                    updateCount();
                }
            });
        }

        if (clearBarcodes) {
            clearBarcodes.addEventListener('click', function () {
                barcodeList.value = '';
                barcodeInput.value = '';
                updateCount();
                barcodeInput.focus();
            });
        }

        updateCount();
    });
    </script>
</body>
</html>