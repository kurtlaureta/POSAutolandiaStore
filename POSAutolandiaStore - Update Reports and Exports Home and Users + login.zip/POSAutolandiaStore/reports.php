<?php
include "db.php";

$view = $_GET['view'] ?? 'summary';
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to   = $_GET['date_to'] ?? date('Y-m-d');

$startDateTime = $date_from . ' 00:00:00';
$endDateTime   = $date_to . ' 23:59:59';

function activeTab($current, $tab) {
    return $current === $tab
        ? 'text-orange-600 border-b-2 border-orange-500 font-semibold'
        : 'text-gray-500 hover:text-orange-500';
}

/* =========================
   GLOBAL SUMMARY
========================= */
$summaryStmt = $conn->prepare("
    SELECT
        COUNT(*) AS total_receipts,
        COALESCE(SUM(total_amount), 0) AS total_sales,
        COALESCE(AVG(total_amount), 0) AS average_sale
    FROM transactions
    WHERE created_at BETWEEN ? AND ?
");
$summaryStmt->bind_param("ss", $startDateTime, $endDateTime);
$summaryStmt->execute();
$summary = $summaryStmt->get_result()->fetch_assoc();

$totalReceipts = (int)($summary['total_receipts'] ?? 0);
$totalSales    = (float)($summary['total_sales'] ?? 0);
$averageSale   = (float)($summary['average_sale'] ?? 0);

$itemSummaryStmt = $conn->prepare("
    SELECT COALESCE(SUM(qty), 0) AS total_items
    FROM transaction_items
    WHERE created_at BETWEEN ? AND ?
");
$itemSummaryStmt->bind_param("ss", $startDateTime, $endDateTime);
$itemSummaryStmt->execute();
$itemSummary = $itemSummaryStmt->get_result()->fetch_assoc();

$totalItemsSold = (int)($itemSummary['total_items'] ?? 0);

/* =========================
   SALES SUMMARY BY DATE
========================= */
$dailyStmt = $conn->prepare("
    SELECT
        DATE(created_at) AS sales_date,
        COUNT(*) AS receipts,
        COALESCE(SUM(total_amount), 0) AS gross_sales,
        COALESCE(AVG(total_amount), 0) AS avg_sale
    FROM transactions
    WHERE created_at BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) DESC
");
$dailyStmt->bind_param("ss", $startDateTime, $endDateTime);
$dailyStmt->execute();
$dailySales = $dailyStmt->get_result();

/* =========================
   SALES BY ITEM
========================= */
$itemStmt = $conn->prepare("
    SELECT
        ti.product_name,
        COALESCE(c.category_name, 'Uncategorized') AS category_name,
        COALESCE(SUM(ti.qty), 0) AS items_sold,
        COALESCE(SUM(ti.subtotal), 0) AS net_sales,
        COALESCE(AVG(ti.price), 0) AS avg_price
    FROM transaction_items ti
    LEFT JOIN products p ON ti.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE ti.created_at BETWEEN ? AND ?
    GROUP BY ti.product_id, ti.product_name, c.category_name
    ORDER BY net_sales DESC, items_sold DESC
");
$itemStmt->bind_param("ss", $startDateTime, $endDateTime);
$itemStmt->execute();
$itemSales = $itemStmt->get_result();

/* =========================
   TOP 5 ITEMS
========================= */
$topItemsStmt = $conn->prepare("
    SELECT
        ti.product_name,
        COALESCE(SUM(ti.subtotal), 0) AS net_sales
    FROM transaction_items ti
    WHERE ti.created_at BETWEEN ? AND ?
    GROUP BY ti.product_id, ti.product_name
    ORDER BY net_sales DESC
    LIMIT 5
");
$topItemsStmt->bind_param("ss", $startDateTime, $endDateTime);
$topItemsStmt->execute();
$topItems = $topItemsStmt->get_result();

/* =========================
   SALES BY CATEGORY
========================= */
$categoryStmt = $conn->prepare("
    SELECT
        COALESCE(c.category_name, 'Uncategorized') AS category_name,
        COALESCE(SUM(ti.qty), 0) AS items_sold,
        COALESCE(SUM(ti.subtotal), 0) AS net_sales
    FROM transaction_items ti
    LEFT JOIN products p ON ti.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE ti.created_at BETWEEN ? AND ?
    GROUP BY c.category_name
    ORDER BY net_sales DESC, items_sold DESC
");
$categoryStmt->bind_param("ss", $startDateTime, $endDateTime);
$categoryStmt->execute();
$categorySales = $categoryStmt->get_result();

/* =========================
   PAYMENT TYPE
   Your schema only shows cash fields,
   so this is a simplified "Cash" report.
========================= */
$paymentStmt = $conn->prepare("
    SELECT
        COUNT(*) AS payment_transactions,
        COALESCE(SUM(total_amount), 0) AS payment_amount
    FROM transactions
    WHERE created_at BETWEEN ? AND ?
");
$paymentStmt->bind_param("ss", $startDateTime, $endDateTime);
$paymentStmt->execute();
$paymentData = $paymentStmt->get_result()->fetch_assoc();

/* =========================
   RECEIPTS
========================= */
$receiptStmt = $conn->prepare("
    SELECT
        id,
        receipt_no,
        total_amount,
        cash_amount,
        change_amount,
        created_at
    FROM transactions
    WHERE created_at BETWEEN ? AND ?
    ORDER BY created_at DESC
");
$receiptStmt->bind_param("ss", $startDateTime, $endDateTime);
$receiptStmt->execute();
$receipts = $receiptStmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 min-h-screen">

<?php include "navbar.php"; ?>

<div class="max-w-7xl mx-auto px-4 md:px-6 pt-24 pb-10">

    <!-- HEADER -->
    <div class="mb-4">
        <h1 class="text-2xl md:text-3xl font-bold text-orange-500">Reports</h1>
        <p class="text-sm text-gray-500">Minimal reporting view with your POS data</p>
    </div>

    <!-- FILTER BAR -->
    <div class="bg-white rounded-2xl shadow-sm border border-orange-100 p-4 mb-4">
        <form method="GET" class="flex flex-col xl:flex-row xl:items-end gap-3">
            <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">

            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Date From</label>
                <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>" class="border rounded-xl px-4 py-2.5 w-full">
            </div>

            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1">Date To</label>
                <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>" class="border rounded-xl px-4 py-2.5 w-full">
            </div>

            <div class="flex gap-2">
                <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-white px-5 py-2.5 rounded-xl font-semibold">
                    Apply
                </button>
                <a href="reports.php?view=<?= urlencode($view) ?>" class="bg-gray-100 hover:bg-gray-200 text-gray-700 px-5 py-2.5 rounded-xl font-semibold">
                    Reset
                </a>
            </div>
        </form>
    </div>

    <!-- TABS -->
    <div class="bg-white rounded-2xl shadow-sm border border-orange-100 mb-4 overflow-x-auto">
        <div class="flex min-w-max px-4 gap-6">
            <a href="reports.php?view=summary&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="py-4 <?= activeTab($view, 'summary') ?>">Sales Summary</a>
            <a href="reports.php?view=items&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="py-4 <?= activeTab($view, 'items') ?>">Sales by Item</a>
            <a href="reports.php?view=categories&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="py-4 <?= activeTab($view, 'categories') ?>">Sales by Category</a>
            <a href="reports.php?view=payments&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="py-4 <?= activeTab($view, 'payments') ?>">Sales by Payment Type</a>
            <a href="reports.php?view=receipts&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>" class="py-4 <?= activeTab($view, 'receipts') ?>">Receipts</a>
        </div>
    </div>

    <!-- MINIMAL SUMMARY STRIP -->
    <div class="bg-white rounded-2xl shadow-sm border border-orange-100 mb-4">
        <div class="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x divide-orange-100">
            <div class="p-5">
                <p class="text-xs uppercase tracking-wide text-gray-500">Receipts</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?= number_format($totalReceipts) ?></p>
            </div>
            <div class="p-5">
                <p class="text-xs uppercase tracking-wide text-gray-500">Sales</p>
                <p class="text-2xl font-bold text-orange-600 mt-1">₱<?= number_format($totalSales, 2) ?></p>
            </div>
            <div class="p-5">
                <p class="text-xs uppercase tracking-wide text-gray-500">Items Sold</p>
                <p class="text-2xl font-bold text-gray-800 mt-1"><?= number_format($totalItemsSold) ?></p>
            </div>
            <div class="p-5">
                <p class="text-xs uppercase tracking-wide text-gray-500">Average Sale</p>
                <p class="text-2xl font-bold text-gray-800 mt-1">₱<?= number_format($averageSale, 2) ?></p>
            </div>
        </div>
    </div>

    <?php if ($view === 'summary'): ?>
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <div class="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-orange-100">
                    <h2 class="font-bold text-gray-800">Sales Summary</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-orange-50 text-gray-600">
                            <tr>
                                <th class="text-left px-5 py-3 font-semibold">Date</th>
                                <th class="text-right px-5 py-3 font-semibold">Receipts</th>
                                <th class="text-right px-5 py-3 font-semibold">Gross Sales</th>
                                <th class="text-right px-5 py-3 font-semibold">Average Sale</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($dailySales && $dailySales->num_rows > 0): ?>
                                <?php while ($row = $dailySales->fetch_assoc()): ?>
                                    <tr class="border-t border-orange-50 hover:bg-orange-50/40 cursor-pointer"
                                        onclick="openDailySalesModal('<?= htmlspecialchars($row['sales_date'], ENT_QUOTES) ?>')">
                                            <td class="px-5 py-3 font-medium text-gray-800"><?= htmlspecialchars($row['sales_date']) ?></td>
                                            <td class="px-5 py-3 text-right"><?= (int)$row['receipts'] ?></td>
                                            <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)$row['gross_sales'], 2) ?></td>
                                            <td class="px-5 py-3 text-right">₱<?= number_format((float)$row['avg_sale'], 2) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="px-5 py-8 text-center text-gray-500">No sales data found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-orange-100">
                    <h2 class="font-bold text-gray-800">Quick Overview</h2>
                </div>
                <div class="p-5 space-y-4">
                    <div>
                        <p class="text-xs text-gray-500 uppercase">Date Range</p>
                        <p class="font-semibold text-gray-800 mt-1"><?= htmlspecialchars($date_from) ?> to <?= htmlspecialchars($date_to) ?></p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 uppercase">Best Simple Metric</p>
                        <p class="font-semibold text-orange-600 mt-1">₱<?= number_format($averageSale, 2) ?> average sale</p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500 uppercase">Notes</p>
                        <p class="text-sm text-gray-600 mt-1">This version is intentionally minimal to match the cleaner reporting style from your screenshots.</p>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($view === 'items'): ?>
        <div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <div class="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-orange-100">
                    <h2 class="font-bold text-gray-800">Top 5 Items</h2>
                </div>
                <div class="p-5 space-y-4">
                    <?php if ($topItems && $topItems->num_rows > 0): ?>
                        <?php while ($row = $topItems->fetch_assoc()): ?>
                            <div class="flex items-center justify-between border-b border-orange-50 pb-3">
                                <p class="text-sm font-medium text-gray-800"><?= htmlspecialchars($row['product_name']) ?></p>
                                <p class="text-sm font-bold text-orange-600">₱<?= number_format((float)$row['net_sales'], 2) ?></p>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-sm text-gray-500">No item sales found.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="xl:col-span-2 bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
                <div class="px-5 py-4 border-b border-orange-100">
                    <h2 class="font-bold text-gray-800">Sales by Item</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="bg-orange-50 text-gray-600">
                            <tr>
                                <th class="text-left px-5 py-3 font-semibold">Item</th>
                                <th class="text-left px-5 py-3 font-semibold">Category</th>
                                <th class="text-right px-5 py-3 font-semibold">Items Sold</th>
                                <th class="text-right px-5 py-3 font-semibold">Net Sales</th>
                                <th class="text-right px-5 py-3 font-semibold">Avg Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($itemSales && $itemSales->num_rows > 0): ?>
                                <?php while ($row = $itemSales->fetch_assoc()): ?>
                                    <tr class="border-t border-orange-50 hover:bg-orange-50/40">
                                        <td class="px-5 py-3 font-medium text-gray-800"><?= htmlspecialchars($row['product_name']) ?></td>
                                        <td class="px-5 py-3"><?= htmlspecialchars($row['category_name']) ?></td>
                                        <td class="px-5 py-3 text-right"><?= (int)$row['items_sold'] ?></td>
                                        <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)$row['net_sales'], 2) ?></td>
                                        <td class="px-5 py-3 text-right">₱<?= number_format((float)$row['avg_price'], 2) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-5 py-8 text-center text-gray-500">No item sales found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <?php elseif ($view === 'categories'): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-orange-100">
                <h2 class="font-bold text-gray-800">Sales by Category</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-orange-50 text-gray-600">
                        <tr>
                            <th class="text-left px-5 py-3 font-semibold">Category</th>
                            <th class="text-right px-5 py-3 font-semibold">Items Sold</th>
                            <th class="text-right px-5 py-3 font-semibold">Net Sales</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($categorySales && $categorySales->num_rows > 0): ?>
                            <?php while ($row = $categorySales->fetch_assoc()): ?>
                                <tr class="border-t border-orange-50 hover:bg-orange-50/40">
                                    <td class="px-5 py-3 font-medium text-gray-800"><?= htmlspecialchars($row['category_name']) ?></td>
                                    <td class="px-5 py-3 text-right"><?= (int)$row['items_sold'] ?></td>
                                    <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)$row['net_sales'], 2) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="px-5 py-8 text-center text-gray-500">No category sales found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php elseif ($view === 'payments'): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-orange-100">
                <h2 class="font-bold text-gray-800">Sales by Payment Type</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-orange-50 text-gray-600">
                        <tr>
                            <th class="text-left px-5 py-3 font-semibold">Payment Type</th>
                            <th class="text-right px-5 py-3 font-semibold">Transactions</th>
                            <th class="text-right px-5 py-3 font-semibold">Amount</th>
                            <th class="text-right px-5 py-3 font-semibold">Refunds</th>
                            <th class="text-right px-5 py-3 font-semibold">Net Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-t border-orange-50 hover:bg-orange-50/40">
                            <td class="px-5 py-3 font-medium text-gray-800">Cash</td>
                            <td class="px-5 py-3 text-right"><?= (int)($paymentData['payment_transactions'] ?? 0) ?></td>
                            <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)($paymentData['payment_amount'] ?? 0), 2) ?></td>
                            <td class="px-5 py-3 text-right">₱0.00</td>
                            <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)($paymentData['payment_amount'] ?? 0), 2) ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    <?php elseif ($view === 'receipts'): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-orange-100 overflow-hidden">
            <div class="px-5 py-4 border-b border-orange-100">
                <h2 class="font-bold text-gray-800">Receipts</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-orange-50 text-gray-600">
                        <tr>
                            <th class="text-left px-5 py-3 font-semibold">Receipt No.</th>
                            <th class="text-left px-5 py-3 font-semibold">Date</th>
                            <th class="text-right px-5 py-3 font-semibold">Amount</th>
                            <th class="text-right px-5 py-3 font-semibold">Cash</th>
                            <th class="text-right px-5 py-3 font-semibold">Change</th>
                            <th class="text-center px-5 py-3 font-semibold">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($receipts && $receipts->num_rows > 0): ?>
                            <?php while ($row = $receipts->fetch_assoc()): ?>
                                <tr class="border-t border-orange-50 hover:bg-orange-50/40">
                                    <td class="px-5 py-3 font-medium text-gray-800"><?= htmlspecialchars($row['receipt_no']) ?></td>
                                    <td class="px-5 py-3"><?= htmlspecialchars($row['created_at']) ?></td>
                                    <td class="px-5 py-3 text-right font-semibold">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                    <td class="px-5 py-3 text-right">₱<?= number_format((float)$row['cash_amount'], 2) ?></td>
                                    <td class="px-5 py-3 text-right">₱<?= number_format((float)$row['change_amount'], 2) ?></td>
                                    <td class="px-5 py-3 text-center">
                                        <a href="report_cards.php?mode=transaction&id=<?= (int)$row['id'] ?>" class="bg-orange-500 hover:bg-orange-600 text-white px-3 py-2 rounded-lg text-xs font-semibold">
                                            View
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="px-5 py-8 text-center text-gray-500">No receipts found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

</div>
<!-- DAILY SALES MODAL -->
<div id="dailySalesModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-black/40" onclick="closeDailySalesModal()"></div>

    <div class="relative z-10 flex items-center justify-center min-h-screen p-4">
        <div class="bg-white w-full max-w-6xl rounded-3xl shadow-2xl overflow-hidden">
            <div class="flex items-center justify-between px-6 py-4 border-b border-orange-100 bg-orange-50">
                <div>
                    <h2 class="text-xl font-bold text-orange-500">Daily Sales Preview</h2>
                    <p class="text-sm text-gray-500">Quick view without leaving reports</p>
                </div>
                <button type="button"
                        onclick="closeDailySalesModal()"
                        class="text-gray-500 hover:text-red-500 text-2xl leading-none">
                    &times;
                </button>
            </div>

            <div id="dailySalesModalBody" class="p-6">
                <div class="text-center text-gray-500 py-10">Loading...</div>
            </div>
        </div>
    </div>
</div>
<script>
function openDailySalesModal(date) {
    const modal = document.getElementById('dailySalesModal');
    const body = document.getElementById('dailySalesModalBody');

    modal.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');

    body.innerHTML = '<div class="text-center text-gray-500 py-10">Loading...</div>';

    fetch('daily_sales_modal.php?date=' + encodeURIComponent(date))
        .then(response => response.text())
        .then(html => {
            body.innerHTML = html;
        })
        .catch(() => {
            body.innerHTML = '<div class="text-center text-red-600 py-10">Failed to load daily sales data.</div>';
        });
}

function closeDailySalesModal() {
    const modal = document.getElementById('dailySalesModal');
    modal.classList.add('hidden');
    document.body.classList.remove('overflow-hidden');
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeDailySalesModal();
    }
});
</script>
</body>
</html>