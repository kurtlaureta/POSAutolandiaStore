<?php
include "db.php";

/*
REQUIREMENT:
Install PhpSpreadsheet first.

If you are using Composer, run this in your project folder:
composer require phpoffice/phpspreadsheet

Then make sure vendor/autoload.php exists.
*/
require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$search = trim($_GET["search"] ?? "");

/* LOAD INVENTORY DATA */
if ($search !== "") {
    $like = "%" . $search . "%";
    $stmt = $conn->prepare("
        SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.product_name LIKE ?
           OR c.category_name LIKE ?
           OR CAST(p.price AS CHAR) LIKE ?
           OR CAST(p.stock_qty AS CHAR) LIKE ?
        ORDER BY p.product_name ASC
    ");
    $stmt->bind_param("ssss", $like, $like, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT p.*, c.category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            ORDER BY p.product_name ASC";
    $result = $conn->query($sql);
}

/* CREATE EXCEL */
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Inventory');

/* TITLE */
$sheet->setCellValue('A1', 'Inventory Export');
$sheet->mergeCells('A1:F1');
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);

/* DATE */
$sheet->setCellValue('A2', 'Export Date: ' . date('Y-m-d H:i:s'));
$sheet->mergeCells('A2:F2');

/* HEADERS */
$headers = ['Product Name', 'Category', 'Price', 'Stock', 'Status', 'Image Path'];
$col = 'A';
$rowHeader = 4;

foreach ($headers as $header) {
    $sheet->setCellValue($col . $rowHeader, $header);
    $sheet->getStyle($col . $rowHeader)->getFont()->setBold(true);
    $col++;
}

/* DATA */
$rowNum = 5;

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $status = ((int)$row['stock_qty'] > 0) ? 'In Stock' : 'Out of Stock';

        $sheet->setCellValue('A' . $rowNum, $row['product_name']);
        $sheet->setCellValue('B' . $rowNum, $row['category_name'] ?? 'N/A');
        $sheet->setCellValue('C' . $rowNum, (float)$row['price']);
        $sheet->setCellValue('D' . $rowNum, (int)$row['stock_qty']);
        $sheet->setCellValue('E' . $rowNum, $status);
        $sheet->setCellValue('F' . $rowNum, $row['product_image'] ?? '');

        $rowNum++;
    }
}

/* FORMAT PRICE COLUMN */
$sheet->getStyle('C5:C' . ($rowNum - 1))
      ->getNumberFormat()
      ->setFormatCode('"₱"#,##0.00');

/* AUTO SIZE COLUMNS */
foreach (range('A', 'F') as $columnID) {
    $sheet->getColumnDimension($columnID)->setAutoSize(true);
}

/* OPTIONAL: ADD BORDERS */
$lastRow = max(4, $rowNum - 1);
$sheet->getStyle("A4:F{$lastRow}")
    ->getBorders()
    ->getAllBorders()
    ->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);

/* DOWNLOAD FILE */
$filename = 'inventory_export_' . date('Ymd_His') . '.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>