<?php
include "db.php";

$mode = $_GET['mode'] ?? '';

if ($mode === 'date') {
    $date = $_GET['date'] ?? '';

    if ($date === '') {
        die("No date selected.");
    }

    $summaryStmt = $conn->prepare("
        SELECT 
            COUNT(*) AS total_transactions,
            COALESCE(SUM(total_amount), 0) AS total_sales
        FROM transactions
        WHERE DATE(created_at) = ?
    ");
    $summaryStmt->bind_param("s", $date);
    $summaryStmt->execute();
    $summary = $summaryStmt->get_result()->fetch_assoc();

    $itemsCountStmt = $conn->prepare("
        SELECT COALESCE(SUM(ti.qty), 0) AS total_items
        FROM transaction_items ti
        INNER JOIN transactions t ON ti.transaction_id = t.id
        WHERE DATE(t.created_at) = ?
    ");
    $itemsCountStmt->bind_param("s", $date);
    $itemsCountStmt->execute();
    $itemsCount = $itemsCountStmt->get_result()->fetch_assoc();

    $transactionsStmt = $conn->prepare("
        SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
        FROM transactions
        WHERE DATE(created_at) = ?
        ORDER BY created_at DESC
    ");
    $transactionsStmt->bind_param("s", $date);
    $transactionsStmt->execute();
    $transactions = $transactionsStmt->get_result();

    $itemsStmt = $conn->prepare("
        SELECT 
            ti.transaction_id,
            ti.product_name,
            ti.barcode,
            ti.price,
            ti.qty,
            ti.subtotal
        FROM transaction_items ti
        INNER JOIN transactions t ON ti.transaction_id = t.id
        WHERE DATE(t.created_at) = ?
        ORDER BY ti.transaction_id DESC, ti.id ASC
    ");
    $itemsStmt->bind_param("s", $date);
    $itemsStmt->execute();
    $itemsResult = $itemsStmt->get_result();

    $itemsByTransaction = [];
    while ($item = $itemsResult->fetch_assoc()) {
        $txId = $item['transaction_id'];
        if (!isset($itemsByTransaction[$txId])) {
            $itemsByTransaction[$txId] = [];
        }
        $itemsByTransaction[$txId][] = $item;
    }
}
elseif ($mode === 'transaction') {
    $id = (int)($_GET['id'] ?? 0);

    if ($id <= 0) {
        die("Invalid transaction ID.");
    }

    $txStmt = $conn->prepare("
        SELECT id, receipt_no, total_amount, cash_amount, change_amount, created_at
        FROM transactions
        WHERE id = ?
        LIMIT 1
    ");
    $txStmt->bind_param("i", $id);
    $txStmt->execute();
    $transaction = $txStmt->get_result()->fetch_assoc();

    if (!$transaction) {
        die("Transaction not found.");
    }

    $itemsStmt = $conn->prepare("
        SELECT product_name, barcode, price, qty, subtotal
        FROM transaction_items
        WHERE transaction_id = ?
        ORDER BY id ASC
    ");
    $itemsStmt->bind_param("i", $id);
    $itemsStmt->execute();
    $transactionItems = $itemsStmt->get_result();
}
else {
    die("Invalid mode.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Cards</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">

<?php include "navbar.php"; ?>

<div class="max-w-7xl mx-auto mt-24">

    <?php if ($mode === 'date'): ?>
        <div class="bg-white rounded-2xl shadow p-6 mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-orange-500">Daily Sales Card View</h1>
                    <p class="text-gray-500">Sales cards for <?= htmlspecialchars($date) ?></p>
                </div>
                <a href="reports.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                    Back to Reports
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="bg-orange-100 rounded-2xl p-5 shadow">
                <p class="text-sm text-gray-600">Date</p>
                <h2 class="text-2xl font-bold text-orange-600"><?= htmlspecialchars($date) ?></h2>
            </div>
            <div class="bg-blue-100 rounded-2xl p-5 shadow">
                <p class="text-sm text-gray-600">Total Transactions</p>
                <h2 class="text-2xl font-bold text-blue-600"><?= (int)($summary['total_transactions'] ?? 0) ?></h2>
            </div>
            <div class="bg-green-100 rounded-2xl p-5 shadow">
                <p class="text-sm text-gray-600">Total Sales</p>
                <h2 class="text-2xl font-bold text-green-600">₱<?= number_format((float)($summary['total_sales'] ?? 0), 2) ?></h2>
                <p class="text-sm text-gray-500 mt-1"><?= (int)($itemsCount['total_items'] ?? 0) ?> item(s) sold</p>
            </div>
        </div>

        <div class="space-y-6">
            <?php if ($transactions && $transactions->num_rows > 0): ?>
                <?php while ($tx = $transactions->fetch_assoc()): ?>
                    <div class="bg-white rounded-2xl shadow overflow-hidden">
                        <div class="bg-orange-100 px-5 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                            <div>
                                <h3 class="text-xl font-bold text-gray-800">Transaction #<?= (int)$tx['id'] ?></h3>
                                <p class="text-sm text-gray-600">Receipt No: <?= htmlspecialchars($tx['receipt_no']) ?></p>
                                <p class="text-sm text-gray-600">Date/Time: <?= htmlspecialchars($tx['created_at']) ?></p>
                            </div>
                            <div class="text-left md:text-right">
                                <p class="text-sm text-gray-600">Cash: ₱<?= number_format((float)$tx['cash_amount'], 2) ?></p>
                                <p class="text-sm text-gray-600">Change: ₱<?= number_format((float)$tx['change_amount'], 2) ?></p>
                                <p class="text-xl font-bold text-orange-600">₱<?= number_format((float)$tx['total_amount'], 2) ?></p>
                            </div>
                        </div>

                        <div class="p-5">
                            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                                <?php if (!empty($itemsByTransaction[$tx['id']])): ?>
                                    <?php foreach ($itemsByTransaction[$tx['id']] as $item): ?>
                                        <div class="border rounded-2xl p-4 bg-orange-50">
                                            <h4 class="font-bold text-gray-800 mb-2"><?= htmlspecialchars($item['product_name']) ?></h4>
                                            <p class="text-sm text-gray-600">Barcode: <?= htmlspecialchars($item['barcode'] ?? '') ?></p>
                                            <p class="text-sm text-gray-600">Price: ₱<?= number_format((float)$item['price'], 2) ?></p>
                                            <p class="text-sm text-gray-600">Quantity: <?= (int)$item['qty'] ?></p>
                                            <p class="text-lg font-bold text-orange-600 mt-2">Subtotal: ₱<?= number_format((float)$item['subtotal'], 2) ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="text-gray-500">No item records found for this transaction.</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="bg-white rounded-2xl shadow p-8 text-center text-gray-500">No transactions found for this date.</div>
            <?php endif; ?>
        </div>

    <?php elseif ($mode === 'transaction'): ?>
        <div class="bg-white rounded-2xl shadow p-6 mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-orange-500">Transaction Card View</h1>
                    <p class="text-gray-500">Detailed card for transaction #<?= (int)$transaction['id'] ?></p>
                </div>
                <a href="reports.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                    Back to Reports
                </a>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow overflow-hidden mb-6">
            <div class="bg-orange-100 px-5 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div>
                    <h3 class="text-2xl font-bold text-gray-800">Transaction #<?= (int)$transaction['id'] ?></h3>
                    <p class="text-sm text-gray-600">Receipt No: <?= htmlspecialchars($transaction['receipt_no']) ?></p>
                    <p class="text-sm text-gray-600">Date/Time: <?= htmlspecialchars($transaction['created_at']) ?></p>
                </div>
                <div class="text-left md:text-right">
                    <p class="text-sm text-gray-600">Cash: ₱<?= number_format((float)$transaction['cash_amount'], 2) ?></p>
                    <p class="text-sm text-gray-600">Change: ₱<?= number_format((float)$transaction['change_amount'], 2) ?></p>
                    <p class="text-2xl font-bold text-orange-600">₱<?= number_format((float)$transaction['total_amount'], 2) ?></p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <?php if ($transactionItems && $transactionItems->num_rows > 0): ?>
                <?php while ($item = $transactionItems->fetch_assoc()): ?>
                    <div class="bg-white rounded-2xl shadow p-5 border">
                        <h4 class="text-lg font-bold text-gray-800 mb-2"><?= htmlspecialchars($item['product_name']) ?></h4>
                        <p class="text-sm text-gray-600">Barcode: <?= htmlspecialchars($item['barcode'] ?? '') ?></p>
                        <p class="text-sm text-gray-600">Price: ₱<?= number_format((float)$item['price'], 2) ?></p>
                        <p class="text-sm text-gray-600">Quantity: <?= (int)$item['qty'] ?></p>
                        <p class="text-xl font-bold text-orange-600 mt-3">Subtotal: ₱<?= number_format((float)$item['subtotal'], 2) ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="bg-white rounded-2xl shadow p-8 text-center text-gray-500">No items found for this transaction.</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>