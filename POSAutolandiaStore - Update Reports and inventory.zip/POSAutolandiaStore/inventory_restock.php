<?php
include "db.php";

$message = "";
$success = false;

$product_id = (int)($_GET["product_id"] ?? $_POST["product_id"] ?? 0);
$selectedProduct = null;

if ($product_id > 0) {
    $stmt = $conn->prepare("
        SELECT p.*, c.category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
        LIMIT 1
    ");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $selectedProduct = $stmt->get_result()->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["restock_product"])) {
    $product_id = (int)($_POST["product_id"] ?? 0);
    $barcode = trim($_POST["barcode"] ?? "");
    $qty = max(1, (int)($_POST["qty"] ?? 1));

    /*
    IF BARCODE IS PROVIDED:
    automatically find the product using that barcode
    */
    if ($barcode !== "") {
        $findByBarcode = $conn->prepare("
            SELECT p.id, p.product_name
            FROM product_barcodes pb
            INNER JOIN products p ON pb.product_id = p.id
            WHERE pb.barcode = ?
            LIMIT 1
        ");
        $findByBarcode->bind_param("s", $barcode);
        $findByBarcode->execute();
        $barcodeProduct = $findByBarcode->get_result()->fetch_assoc();

        if ($barcodeProduct) {
            $product_id = (int)$barcodeProduct["id"];
        }
    }

    if ($product_id <= 0) {
        $message = "Please select a product, or scan a valid barcode.";
    } else {
        $stmt = $conn->prepare("SELECT id, product_name FROM products WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $selectedProduct = $stmt->get_result()->fetch_assoc();

        if (!$selectedProduct) {
            $message = "No product found for restocking.";
        } else {
            $conn->begin_transaction();

            try {
                if ($barcode !== "") {
                    $insertBarcode = $conn->prepare("
                        INSERT INTO product_barcodes (product_id, barcode, is_sold)
                        VALUES (?, ?, 0)
                    ");

                    for ($i = 0; $i < $qty; $i++) {
                        $insertBarcode->bind_param("is", $product_id, $barcode);
                        $insertBarcode->execute();
                    }
                }

                $updateStock = $conn->prepare("
                    UPDATE products
                    SET stock_qty = stock_qty + ?
                    WHERE id = ?
                ");
                $updateStock->bind_param("ii", $qty, $product_id);
                $updateStock->execute();

                $conn->commit();

                if ($barcode === "") {
                    $message = "Successfully restocked {$selectedProduct['product_name']} with {$qty} no-barcode item(s).";
                } else {
                    $message = "Successfully restocked {$selectedProduct['product_name']} with {$qty} item(s) using barcode {$barcode}.";
                }
                $success = true;
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Restock failed: " . $e->getMessage();
            }
        }
    }
}

$products = $conn->query("SELECT id, product_name, stock_qty FROM products ORDER BY product_name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restock Product</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-4xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex items-center justify-between mb-4">
            <div>
                <h1 class="text-2xl font-bold text-orange-500">Restock Product / Add Barcode</h1>
                <p class="text-gray-500">If barcode exists, product is detected automatically. Leave barcode blank for no-barcode items.</p>
            </div>
            <a href="inventory.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-xl font-semibold">
                Back
            </a>
        </div>

        <?php if ($message): ?>
            <div class="mb-4 p-3 rounded-xl <?= $success ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-5">
            <div>
                <label class="block font-medium mb-1">Select Product</label>
                <select name="product_id" class="w-full border rounded-xl px-4 py-2">
                    <option value="">Choose existing product</option>
                    <?php while ($prod = $products->fetch_assoc()): ?>
                        <option value="<?= (int)$prod['id'] ?>" <?= ($product_id === (int)$prod['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($prod['product_name']) ?> (Stock: <?= (int)$prod['stock_qty'] ?>)
                        </option>
                    <?php endwhile; ?>
                </select>
                <p class="text-sm text-gray-500 mt-1">
                    Optional if barcode is already known by the system.
                </p>
            </div>

            <?php if ($selectedProduct): ?>
                <div class="bg-orange-50 border border-orange-200 rounded-2xl p-4">
                    <p><span class="font-bold">Product:</span> <?= htmlspecialchars($selectedProduct['product_name']) ?></p>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block font-medium mb-2">Barcode (Optional)</label>
                    <input
                        type="text"
                        name="barcode"
                        class="w-full border rounded-xl px-4 py-3"
                        placeholder="Scan barcode or leave blank"
                    >
                    <p class="text-sm text-gray-500 mt-1">
                        If barcode exists, product is auto-detected.
                    </p>
                </div>

                <div>
                    <label class="block font-medium mb-2">Quantity</label>
                    <input
                        type="number"
                        name="qty"
                        min="1"
                        value="1"
                        class="w-full border rounded-xl px-4 py-3"
                        required
                    >
                </div>
            </div>

            <div class="flex justify-between">
                <button type="submit" name="restock_product" class="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-xl font-semibold cursor-pointer">
                    Restock Product
                </button>
                <a href="inventory.php" class="block px-6 py-2 text-white bg-red-400 hover:bg-red-500 rounded-2xl text-center">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</body>
</html>