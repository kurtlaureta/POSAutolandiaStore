<?php
include "db.php";

$sql = "SELECT * FROM transactions ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-orange-50 p-6">
    <?php include "navbar.php"; ?>

    <div class="max-w-7xl mx-auto bg-white rounded-2xl shadow p-6 mt-24">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
                <h1 class="text-2xl font-bold text-orange-500">Transactions</h1>
                <p class="text-gray-500">All completed checkout records.</p>
            </div>
            <a href="transactions_items.php" class="bg-orange-400 hover:bg-orange-500 text-white px-4 py-2 rounded-xl font-semibold">
                View All Transaction Items
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-orange-100 text-left">
                        <th class="p-3">ID</th>
                        <th class="p-3">Receipt No</th>
                        <th class="p-3">Total</th>
                        <th class="p-3">Cash</th>
                        <th class="p-3">Change</th>
                        <th class="p-3">Date</th>
                        <th class="p-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-b hover:bg-orange-50">
                                <td class="p-3 font-medium"><?= (int)$row['id'] ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['receipt_no']) ?></td>
                                <td class="p-3">₱<?= number_format((float)$row['total_amount'], 2) ?></td>
                                <td class="p-3">₱<?= number_format((float)$row['cash_amount'], 2) ?></td>
                                <td class="p-3">₱<?= number_format((float)$row['change_amount'], 2) ?></td>
                                <td class="p-3"><?= htmlspecialchars($row['created_at'] ?? '') ?></td>
                                <td class="p-3">
                                    <a href="transactions_items.php?transaction_id=<?= (int)$row['id'] ?>"
                                       class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-2 rounded-lg text-sm font-semibold">
                                        View Items
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="p-6 text-center text-gray-500">No transactions found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>